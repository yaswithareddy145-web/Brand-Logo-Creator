export type Industry =
  | 'Technology'
  | 'Education'
  | 'Fashion'
  | 'Food'
  | 'Healthcare'
  | 'Gaming'
  | 'Beauty'
  | 'Finance'
  | 'Travel'
  | 'Other';

export type LogoStyle =
  | 'Minimalist'
  | 'Modern'
  | 'Luxury'
  | 'Vintage'
  | 'Abstract'
  | 'Mascot'
  | 'Geometric'
  | 'Lettermark';

export type LogoLayout = 'horizontal' | 'vertical' | 'stacked' | 'badge' | 'icon-only';

export type TextAlignment = 'left' | 'center' | 'right';

export interface ColorPalette {
  id: string;
  name: string;
  primary: string;
  secondary: string;
  accent: string;
  textColor: string;
  taglineColor: string;
  backgroundColor: string;
}

export interface LogoConfig {
  id: string;
  brandName: string;
  tagline: string;
  industry: Industry;
  style: LogoStyle;
  conceptName?: string;
  rationale?: string;
  
  // Visual layout & dimensions
  layout: LogoLayout;
  alignment: TextAlignment;
  
  // Typography
  fontFamily: string;
  fontWeight: string;
  letterSpacing: number; // in px or em
  textSize: number; // pt or px
  textTransform: 'none' | 'uppercase' | 'capitalize' | 'lowercase';
  
  taglineFont: string;
  taglineSize: number;
  taglineLetterSpacing: number;
  taglineTransform: 'none' | 'uppercase' | 'capitalize' | 'lowercase';
  
  // Icon styling
  iconSvg: string; // raw SVG paths or shapes
  iconSize: number;
  iconRotation: number;
  iconShapeBackground?: 'none' | 'circle' | 'square' | 'rounded' | 'hexagon' | 'shield';
  
  // Colors
  primaryColor: string;
  secondaryColor: string;
  accentColor: string;
  textColor: string;
  taglineColor: string;
  backgroundColor: string; // can be 'transparent' or hex
  
  // Toggles
  showTagline: boolean;
  showIcon: boolean;
  hasTransparentBg: boolean;
  
  // Optional raster generation artifact
  imageUrl?: string;
  
  createdAt: string;
  updatedAt: string;
}

export interface GenerationRequest {
  brandName: string;
  tagline?: string;
  industry: Industry;
  style: LogoStyle;
  colorPalette?: ColorPalette;
  customColors?: {
    primary: string;
    secondary: string;
    accent: string;
  };
  symbolPreference?: string;
  description?: string;
  variationsCount: number;
}

export type MockupType = 'business-card' | 't-shirt' | 'product-packaging' | 'storefront' | 'website-header';
