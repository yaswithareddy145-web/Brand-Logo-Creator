/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { LogoConfig } from './types/logo';
import { SAMPLE_LOGOS } from './utils/logoTemplates';
import { getSavedLogos } from './utils/storage';
import { Navbar } from './components/Navbar';
import { HomePage } from './components/HomePage';
import { LogoStudio } from './components/LogoStudio';
import { LogoEditor } from './components/LogoEditor';
import { MyDesigns } from './components/MyDesigns';

export default function App() {
  const [currentTab, setCurrentTab] = useState<'home' | 'create' | 'editor' | 'designs' | 'features'>('home');
  const [activeEditingLogo, setActiveEditingLogo] = useState<LogoConfig>(SAMPLE_LOGOS[0]);
  const [initialStudioBrand, setInitialStudioBrand] = useState<string>('');
  const [savedCount, setSavedCount] = useState<number>(0);

  const refreshSavedCount = () => {
    const list = getSavedLogos();
    setSavedCount(list.length);
  };

  useEffect(() => {
    refreshSavedCount();
  }, [currentTab]);

  const handleNavigate = (tab: 'home' | 'create' | 'designs' | 'features') => {
    if (tab === 'features') {
      if (currentTab !== 'home') {
        setCurrentTab('home');
        setTimeout(() => {
          document.getElementById('features-section')?.scrollIntoView({ behavior: 'smooth' });
        }, 100);
      } else {
        document.getElementById('features-section')?.scrollIntoView({ behavior: 'smooth' });
      }
      return;
    }

    setCurrentTab(tab);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleCreateClick = (initialBrand?: string) => {
    if (initialBrand) {
      setInitialStudioBrand(initialBrand);
    }
    setCurrentTab('create');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleExploreExamples = () => {
    if (currentTab !== 'home') {
      setCurrentTab('home');
      setTimeout(() => {
        document.getElementById('sample-gallery-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 100);
    } else {
      document.getElementById('sample-gallery-section')?.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectSampleLogo = (logo: LogoConfig) => {
    setActiveEditingLogo(logo);
    setCurrentTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenEditor = (logo: LogoConfig) => {
    setActiveEditingLogo(logo);
    setCurrentTab('editor');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-slate-50/50 text-slate-900 font-sans antialiased selection:bg-indigo-500/20 selection:text-indigo-900">
      {/* Top Main Navigation */}
      <Navbar
        currentTab={currentTab}
        onNavigate={handleNavigate}
        savedCount={savedCount}
      />

      {/* Main View Router */}
      <main className="w-full">
        {currentTab === 'home' && (
          <HomePage
            onCreateClick={handleCreateClick}
            onExploreExamples={handleExploreExamples}
            onSelectSampleLogo={handleSelectSampleLogo}
            onNavigateToTab={handleNavigate}
          />
        )}

        {currentTab === 'create' && (
          <LogoStudio
            initialBrandName={initialStudioBrand}
            onSelectLogoForEdit={handleOpenEditor}
          />
        )}

        {currentTab === 'editor' && (
          <LogoEditor
            initialLogo={activeEditingLogo}
            onBackToStudio={() => {
              setCurrentTab('create');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            onSaved={() => refreshSavedCount()}
          />
        )}

        {currentTab === 'designs' && (
          <MyDesigns
            onOpenEditor={handleOpenEditor}
            onCreateNew={() => {
              setInitialStudioBrand('');
              setCurrentTab('create');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
          />
        )}
      </main>
    </div>
  );
}
