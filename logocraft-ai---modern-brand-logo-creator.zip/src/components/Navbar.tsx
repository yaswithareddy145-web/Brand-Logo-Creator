import React, { useState } from 'react';
import { Sparkles, Layers, Wand2, Bookmark, Menu, X, ArrowRight } from 'lucide-react';

interface NavbarProps {
  currentTab: 'home' | 'create' | 'editor' | 'designs' | 'features';
  onNavigate: (tab: 'home' | 'create' | 'designs' | 'features') => void;
  savedCount?: number;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentTab,
  onNavigate,
  savedCount = 0,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (tab: 'home' | 'create' | 'designs' | 'features') => {
    onNavigate(tab);
    setMobileMenuOpen(false);
  };

  return (
    <header className="sticky top-0 z-40 bg-white/90 backdrop-blur-md border-b border-slate-200/80 transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 sm:h-18">
          {/* Brand Logo */}
          <button
            onClick={() => handleNavClick('home')}
            className="flex items-center gap-2.5 text-left group focus:outline-none"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-blue-600 flex items-center justify-center text-white shadow-md shadow-indigo-500/25 group-hover:scale-105 transition">
              <span className="font-black text-sm tracking-tighter">LC</span>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-lg font-extrabold text-slate-900 tracking-tight group-hover:text-indigo-600 transition">
                  LogoCraft
                </span>
                <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded-md bg-indigo-50 text-indigo-600 border border-indigo-100">
                  AI
                </span>
              </div>
            </div>
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden md:flex items-center gap-1 bg-slate-100/70 p-1.5 rounded-full border border-slate-200/60">
            <button
              onClick={() => handleNavClick('home')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition ${
                currentTab === 'home'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Home
            </button>

            <button
              onClick={() => handleNavClick('create')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition flex items-center gap-1.5 ${
                currentTab === 'create'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Wand2 className="w-3.5 h-3.5 text-indigo-500" />
              <span>Create Logo</span>
            </button>

            <button
              onClick={() => handleNavClick('designs')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition flex items-center gap-1.5 ${
                currentTab === 'designs'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Bookmark className="w-3.5 h-3.5 text-purple-500" />
              <span>My Designs</span>
              {savedCount > 0 && (
                <span className="w-4 h-4 rounded-full bg-indigo-600 text-white text-[10px] font-bold flex items-center justify-center">
                  {savedCount}
                </span>
              )}
            </button>

            <button
              onClick={() => handleNavClick('features')}
              className={`px-4 py-1.5 rounded-full text-xs font-semibold transition ${
                currentTab === 'features'
                  ? 'bg-white text-indigo-600 shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Features
            </button>
          </nav>

          {/* Desktop CTA Button */}
          <div className="hidden md:flex items-center gap-3">
            <button
              onClick={() => handleNavClick('create')}
              className="px-5 py-2.5 rounded-xl font-bold text-xs text-white bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 shadow-md shadow-indigo-500/20 transition active:scale-95 flex items-center gap-1.5"
            >
              <span>Get Started</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Mobile Menu Toggle Button */}
          <div className="flex md:hidden items-center gap-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl text-slate-600 hover:bg-slate-100 transition"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-slate-200 bg-white px-4 pt-2 pb-6 space-y-2 animate-in slide-in-from-top-2">
          <button
            onClick={() => handleNavClick('home')}
            className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              currentTab === 'home' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-700'
            }`}
          >
            Home
          </button>

          <button
            onClick={() => handleNavClick('create')}
            className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition flex items-center justify-between ${
              currentTab === 'create' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <Wand2 className="w-4 h-4 text-indigo-500" />
              Create Logo
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-indigo-100 text-indigo-700 font-bold">
              AI
            </span>
          </button>

          <button
            onClick={() => handleNavClick('designs')}
            className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition flex items-center justify-between ${
              currentTab === 'designs' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-700'
            }`}
          >
            <span className="flex items-center gap-2">
              <Bookmark className="w-4 h-4 text-purple-500" />
              My Designs
            </span>
            {savedCount > 0 && (
              <span className="text-xs px-2 py-0.5 rounded-full bg-indigo-600 text-white font-bold">
                {savedCount}
              </span>
            )}
          </button>

          <button
            onClick={() => handleNavClick('features')}
            className={`w-full text-left px-4 py-2.5 rounded-xl text-sm font-semibold transition ${
              currentTab === 'features' ? 'bg-indigo-50 text-indigo-600 font-bold' : 'text-slate-700'
            }`}
          >
            Features
          </button>

          <div className="pt-2">
            <button
              onClick={() => handleNavClick('create')}
              className="w-full py-3 rounded-xl font-bold text-center text-sm text-white bg-gradient-to-r from-indigo-600 to-purple-600 shadow-md transition"
            >
              Get Started Now
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
