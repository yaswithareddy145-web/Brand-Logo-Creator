import React, { useState } from 'react';
import { SAMPLE_LOGOS } from '../utils/logoTemplates';
import { LogoConfig } from '../types/logo';
import { LogoRenderer } from './LogoRenderer';
import {
  Sparkles,
  ArrowRight,
  Layers,
  Wand2,
  Download,
  Sliders,
  CheckCircle2,
  ShieldCheck,
  Zap,
  Palette,
  ChevronDown,
  Star,
  Globe,
  ExternalLink,
} from 'lucide-react';

interface HomePageProps {
  onCreateClick: (initialBrand?: string) => void;
  onExploreExamples: () => void;
  onSelectSampleLogo: (logo: LogoConfig) => void;
  onNavigateToTab: (tab: 'home' | 'create' | 'designs' | 'features') => void;
}

export const HomePage: React.FC<HomePageProps> = ({
  onCreateClick,
  onExploreExamples,
  onSelectSampleLogo,
}) => {
  const [quickBrand, setQuickBrand] = useState('');
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const handleHeroSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onCreateClick(quickBrand);
  };

  const faqs = [
    {
      q: 'Are the generated logos vectors or low-res images?',
      a: 'LogoCraft AI creates genuine vector geometries with mathematically clean SVG paths. This means your logo can scale from a 16px favicon to a billboard with zero loss of quality, and exports into clean SVG code or transparent high-res PNGs.',
    },
    {
      q: 'Do I get full commercial rights to my logos?',
      a: 'Yes! Once you customize and export your logo, you possess full commercial rights to use it on your digital apps, merchandise, corporate stationery, social media, and billboards.',
    },
    {
      q: 'Can I edit the generated designs?',
      a: 'Absolutely. Every generated concept can be opened in the full Logo Editor where you can modify typography, fonts, letter spacing, colors, icon rotation, layouts, and emblem badge styles.',
    },
    {
      q: 'How does Gemini AI generate logo concepts?',
      a: 'Our secure server-side implementation leverages Gemini 3.8 Flash to interpret your industry archetype, symbolism preferences, and aesthetic tone, producing custom vector parameters, font pairings, and design rationales.',
    },
    {
      q: 'What formats can I download?',
      a: 'You can download clean vector SVGs (.svg), high-resolution PNGs (up to 2400px), and transparent-background PNGs tailored for web headers and dark backgrounds.',
    },
  ];

  return (
    <div className="w-full flex flex-col min-h-screen bg-slate-50/50">
      {/* HERO SECTION */}
      <section className="relative overflow-hidden pt-12 pb-20 lg:pt-20 lg:pb-28">
        {/* Subtle background glow spheres */}
        <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[450px] bg-gradient-to-tr from-purple-200/40 via-indigo-200/30 to-blue-200/40 blur-3xl pointer-events-none rounded-full" />

        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          {/* Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/90 backdrop-blur border border-indigo-100 shadow-xs text-xs font-semibold text-indigo-700 mb-6">
            <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
            <span>Next-Gen AI Vector Identity Architecture</span>
          </div>

          {/* Main Hero Headings */}
          <h1 className="text-4xl sm:text-6xl lg:text-7xl font-extrabold text-slate-900 tracking-tight leading-[1.1] max-w-4xl mx-auto">
            Create a Logo That{' '}
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600">
              Defines Your Brand.
            </span>
          </h1>

          <p className="mt-6 text-base sm:text-xl text-slate-600 max-w-2xl mx-auto font-normal leading-relaxed">
            Turn your ideas into memorable brand identities with AI. Generate vector symbols,
            pair luxury typography, preview photorealistic mockups, and export clean SVGs.
          </p>

          {/* Hero Quick Input & CTA */}
          <form
            onSubmit={handleHeroSubmit}
            className="mt-9 max-w-xl mx-auto flex flex-col sm:flex-row items-center gap-3 bg-white p-2 sm:p-2.5 rounded-2xl sm:rounded-full border border-slate-200/90 shadow-xl shadow-indigo-500/5 transition focus-within:ring-2 focus-within:ring-indigo-500/20 focus-within:border-indigo-500"
          >
            <input
              type="text"
              value={quickBrand}
              onChange={(e) => setQuickBrand(e.target.value)}
              placeholder="Enter your brand or company name..."
              className="w-full px-5 py-3 text-sm text-slate-900 placeholder:text-slate-400 bg-transparent focus:outline-none font-medium"
            />
            <button
              type="submit"
              className="w-full sm:w-auto px-7 py-3.5 rounded-xl sm:rounded-full font-bold text-white bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 hover:from-indigo-700 hover:to-blue-700 shadow-md shadow-indigo-500/25 transition active:scale-95 whitespace-nowrap flex items-center justify-center gap-2 text-sm"
            >
              <span>Create My Logo</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Secondary Button & Highlights */}
          <div className="mt-5 flex flex-wrap items-center justify-center gap-6 text-xs text-slate-500 font-medium">
            <button
              onClick={onExploreExamples}
              className="text-indigo-600 font-semibold hover:text-indigo-800 transition flex items-center gap-1"
            >
              Explore Sample Logos ↓
            </button>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              100% Vector SVG
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              Transparent PNG Export
            </span>
            <span>•</span>
            <span className="flex items-center gap-1.5">
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />
              Commercial Rights
            </span>
          </div>
        </div>
      </section>

      {/* SAMPLE LOGOS GALLERY */}
      <section id="sample-gallery-section" className="py-16 bg-white border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-12">
            <h2 className="text-xs uppercase tracking-widest font-extrabold text-indigo-600 mb-2">
              Curated Showcase
            </h2>
            <h3 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
              Sample Logos Crafted with LogoCraft AI
            </h3>
            <p className="text-slate-500 text-sm mt-2">
              Click any design to customize its typography, mark geometry, palette, and live mockups in our editor.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {SAMPLE_LOGOS.map((sample) => (
              <div
                key={sample.id}
                onClick={() => onSelectSampleLogo(sample)}
                className="group relative bg-slate-50/60 hover:bg-white rounded-3xl border border-slate-200/80 hover:border-indigo-300 shadow-xs hover:shadow-xl transition-all duration-300 p-6 flex flex-col justify-between cursor-pointer overflow-hidden"
              >
                {/* Header Tag */}
                <div className="flex items-center justify-between pb-4 border-b border-slate-100">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold text-slate-900">{sample.brandName}</span>
                    <span className="text-[10px] font-semibold text-slate-400">•</span>
                    <span className="text-[10px] uppercase font-bold text-indigo-600 bg-indigo-50 px-2 py-0.5 rounded-full">
                      {sample.industry}
                    </span>
                  </div>
                  <span className="text-[10px] text-slate-400 font-medium">{sample.style}</span>
                </div>

                {/* Render canvas */}
                <div className="py-8 flex items-center justify-center min-h-[200px] transition group-hover:scale-105">
                  <LogoRenderer config={sample} scale={0.78} />
                </div>

                {/* Card Action hover */}
                <div className="pt-4 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 line-clamp-1 text-[11px] font-medium">
                    {sample.conceptName}
                  </span>
                  <span className="font-bold text-indigo-600 flex items-center gap-1 group-hover:translate-x-0.5 transition">
                    Customize <ExternalLink className="w-3 h-3" />
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="py-20 bg-slate-50/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs uppercase tracking-widest font-extrabold text-indigo-600 mb-2">
              Seamless Workflow
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              From Idea to Identity in 3 Simple Steps
            </h3>
            <p className="text-slate-500 text-sm mt-2">
              Intuitive controls, instant AI synthesis, and export-ready vectors without the learning curve.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Step 1 */}
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-lg transition">
              <div className="w-12 h-12 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center font-extrabold text-lg mb-6 shadow-xs">
                1
              </div>
              <h4 className="text-lg font-bold text-slate-900 mb-2">Specify Your Brand Archetype</h4>
              <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                Provide your company name, slogan, industry, style aesthetic (Minimalist, Modern, Luxury, etc.), and palette preferences.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-lg transition">
              <div className="w-12 h-12 rounded-2xl bg-purple-50 text-purple-600 flex items-center justify-center font-extrabold text-lg mb-6 shadow-xs">
                2
              </div>
              <h4 className="text-lg font-bold text-slate-900 mb-2">AI Vector Geometry Synthesis</h4>
              <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                Gemini 3.8 Flash designs tailored emblem marks, typographic arrangements, and balanced proportions tailored to your industry.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-white rounded-3xl p-8 border border-slate-200 shadow-sm relative overflow-hidden group hover:shadow-lg transition">
              <div className="w-12 h-12 rounded-2xl bg-blue-50 text-blue-600 flex items-center justify-center font-extrabold text-lg mb-6 shadow-xs">
                3
              </div>
              <h4 className="text-lg font-bold text-slate-900 mb-2">Live Editor & Production Export</h4>
              <p className="text-slate-500 text-xs sm:text-sm leading-relaxed">
                Fine-tune fonts, sizes, colors, and layout. Preview on realistic business cards and apparel, then export crisp vector SVGs and PNGs.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CORE FEATURES SECTION */}
      <section id="features-section" className="py-20 bg-white border-t border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-xs uppercase tracking-widest font-extrabold text-indigo-600 mb-2">
              Built for Modern Brands
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Everything Needed for a Complete Brand Identity
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="p-6 rounded-3xl bg-slate-50/70 border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-indigo-600 text-white flex items-center justify-center mb-4 shadow-md shadow-indigo-500/20">
                <Wand2 className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1.5">AI-Powered Vector Generation</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Generates scalable math-driven vector marks rather than pixelated art, ensuring pristine reproduction across any resolution.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50/70 border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-purple-600 text-white flex items-center justify-center mb-4 shadow-md shadow-purple-500/20">
                <Sliders className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1.5">Precision Vector Editor</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Tweak fonts, letter spacing, emblem size, rotation, background transparency, and multi-tier color harmonies in real-time.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50/70 border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-blue-600 text-white flex items-center justify-center mb-4 shadow-md shadow-blue-500/20">
                <Layers className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1.5">Photorealistic Mockup Studio</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Test your brand mark immediately on luxury business cards, screenprinted streetwear, product boxes, architectural storefronts, and web headers.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50/70 border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-4 shadow-md shadow-emerald-500/20">
                <Download className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1.5">Full Vector SVG & Transparent PNG</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Download clean, valid XML SVG files or high-resolution PNGs with transparent backgrounds ready for websites, pitch decks, and print.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50/70 border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-rose-600 text-white flex items-center justify-center mb-4 shadow-md shadow-rose-500/20">
                <Palette className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1.5">Color Psychology Harmonies</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Select from curated SaaS gradients, luxury golds, cyber neons, or configure custom hex palettes with automatic contrast balancing.
              </p>
            </div>

            <div className="p-6 rounded-3xl bg-slate-50/70 border border-slate-200">
              <div className="w-10 h-10 rounded-xl bg-amber-600 text-white flex items-center justify-center mb-4 shadow-md shadow-amber-500/20">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="text-base font-bold text-slate-900 mb-1.5">Local Storage & Version History</h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Save multiple brand iterations to My Designs, reopen anytime, and revert changes with built-in Undo / Reset controls.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-20 bg-slate-50/50 border-t border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-2xl mx-auto mb-14">
            <h2 className="text-xs uppercase tracking-widest font-extrabold text-indigo-600 mb-2">
              User Experiences
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Trusted by Founders and Creatives Worldwide
            </h3>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-7 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1 text-amber-400 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-slate-700 text-xs sm:text-sm leading-relaxed mb-6">
                  "LogoCraft AI generated a crisp vector emblem for our fintech startup in under 3 minutes.
                  The mockups on business cards helped us pitch our angel round with total confidence."
                </p>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                <div className="w-9 h-9 rounded-full bg-indigo-100 text-indigo-700 font-bold flex items-center justify-center text-xs">
                  DK
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-900">David Kowalski</h5>
                  <p className="text-[11px] text-slate-500">Co-founder, Nexus Pay</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-7 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1 text-amber-400 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-slate-700 text-xs sm:text-sm leading-relaxed mb-6">
                  "The ability to export clean SVGs with true vector paths rather than blurry raster graphics
                  makes LogoCraft AI completely superior to other generators."
                </p>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                <div className="w-9 h-9 rounded-full bg-purple-100 text-purple-700 font-bold flex items-center justify-center text-xs">
                  MR
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-900">Maya Rosenthal</h5>
                  <p className="text-[11px] text-slate-500">Creative Lead, Studio Forma</p>
                </div>
              </div>
            </div>

            <div className="bg-white p-7 rounded-3xl border border-slate-200 shadow-sm flex flex-col justify-between">
              <div>
                <div className="flex items-center gap-1 text-amber-400 mb-3">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                </div>
                <p className="text-slate-700 text-xs sm:text-sm leading-relaxed mb-6">
                  "The live editor gives you full control over typography, letter spacing, and colors.
                  I customized 4 logo options for our organic matcha brand in one afternoon."
                </p>
              </div>
              <div className="flex items-center gap-3 pt-4 border-t border-slate-100">
                <div className="w-9 h-9 rounded-full bg-emerald-100 text-emerald-700 font-bold flex items-center justify-center text-xs">
                  JL
                </div>
                <div>
                  <h5 className="text-xs font-bold text-slate-900">Julian Lin</h5>
                  <p className="text-[11px] text-slate-500">Brand Director, Verdant Botanic</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ SECTION */}
      <section className="py-20 bg-white border-t border-slate-200/80">
        <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-xs uppercase tracking-widest font-extrabold text-indigo-600 mb-2">
              Frequently Asked Questions
            </h2>
            <h3 className="text-3xl font-extrabold text-slate-900 tracking-tight">
              Got Questions? We’ve Got Answers.
            </h3>
          </div>

          <div className="space-y-3">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="rounded-2xl border border-slate-200 overflow-hidden bg-slate-50/40 transition"
              >
                <button
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="w-full p-5 text-left flex items-center justify-between gap-4 font-bold text-sm text-slate-900 hover:text-indigo-600 transition"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`w-4 h-4 text-slate-400 transition-transform duration-200 ${
                      openFaq === idx ? 'rotate-180 text-indigo-600' : ''
                    }`}
                  />
                </button>
                {openFaq === idx && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-slate-600 leading-relaxed border-t border-slate-100/80 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA BANNER */}
      <section className="py-16 bg-gradient-to-r from-indigo-900 via-indigo-800 to-purple-900 text-white relative overflow-hidden">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 text-center relative z-10">
          <h3 className="text-3xl sm:text-4xl font-extrabold tracking-tight">
            Ready to Build Your Brand Identity?
          </h3>
          <p className="mt-3 text-indigo-200 text-sm sm:text-base max-w-xl mx-auto">
            Generate unlimited original vector logos, customize every detail, and download production-ready files in seconds.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <button
              onClick={() => onCreateClick()}
              className="px-8 py-3.5 rounded-full bg-white text-indigo-900 font-bold text-sm shadow-xl hover:bg-indigo-50 transition active:scale-95 flex items-center gap-2"
            >
              <span>Get Started Now</span>
              <ArrowRight className="w-4 h-4" />
            </button>
            <button
              onClick={onExploreExamples}
              className="px-7 py-3.5 rounded-full bg-indigo-700/50 hover:bg-indigo-700/70 text-white border border-indigo-500/40 font-semibold text-sm transition"
            >
              View Sample Gallery
            </button>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-slate-950 text-slate-400 py-12 border-t border-slate-900">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-10">
            <div className="md:col-span-1">
              <div className="flex items-center gap-2 text-white font-extrabold text-base tracking-tight mb-3">
                <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-indigo-500 to-purple-600 flex items-center justify-center text-white text-xs font-black shadow-md shadow-indigo-500/30">
                  LC
                </div>
                <span>LogoCraft AI</span>
              </div>
              <p className="text-xs text-slate-400 leading-relaxed">
                AI-driven brand identity studio providing vector logo synthesis, precision live editing, and realistic product mockups.
              </p>
            </div>

            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Industries</h5>
              <ul className="space-y-2 text-xs">
                <li>Technology & SaaS</li>
                <li>Finance & Venture</li>
                <li>Healthcare & Bio</li>
                <li>Gaming & Esports</li>
                <li>Food & Beverage</li>
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Export Formats</h5>
              <ul className="space-y-2 text-xs">
                <li>Scalable Vector SVG (.svg)</li>
                <li>Transparent PNG (.png)</li>
                <li>High-Res 2400px Bitmap</li>
                <li>Custom CSS & Hex Palettes</li>
                <li>Commercial Print Specs</li>
              </ul>
            </div>

            <div>
              <h5 className="text-xs font-bold text-white uppercase tracking-wider mb-3">Architecture</h5>
              <p className="text-xs text-slate-400 mb-2">
                Server-side Gemini 3.8 Flash pipeline with full-stack Express API, React 19, and Tailwind CSS.
              </p>
              <div className="flex items-center gap-2 text-xs text-emerald-400">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>AI Pipeline Operational</span>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between text-xs text-slate-500 gap-4">
            <div>© {new Date().getFullYear()} LogoCraft AI. All brand marks and commercial rights belong to the user.</div>
            <div className="flex items-center gap-6">
              <span>Privacy Policy</span>
              <span>Terms of Service</span>
              <span>Vector Guidelines</span>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};
