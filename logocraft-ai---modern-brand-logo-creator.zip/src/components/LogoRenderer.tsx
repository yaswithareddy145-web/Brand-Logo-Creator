import React from 'react';
import { LogoConfig } from '../types/logo';

interface LogoRendererProps {
  config: LogoConfig;
  className?: string;
  showTransparentGrid?: boolean;
  scale?: number;
}

export const LogoRenderer: React.FC<LogoRendererProps> = ({
  config,
  className = '',
  showTransparentGrid = false,
  scale = 1,
}) => {
  const isTransparent = config.hasTransparentBg;
  const isHorizontal = config.layout === 'horizontal';
  const isVertical = config.layout === 'vertical';
  const isStacked = config.layout === 'stacked';
  const isBadge = config.layout === 'badge';
  const isIconOnly = config.layout === 'icon-only';

  // Compute icon container styling
  const iconBaseSize = (config.iconSize || 48) * scale;

  const renderIconBadgeWrapper = (children: React.ReactNode) => {
    if (!config.iconShapeBackground || config.iconShapeBackground === 'none') {
      return children;
    }

    let shapeClasses = 'flex items-center justify-center p-3 transition-transform';
    if (config.iconShapeBackground === 'circle') shapeClasses += ' rounded-full';
    if (config.iconShapeBackground === 'square') shapeClasses += ' rounded-none';
    if (config.iconShapeBackground === 'rounded') shapeClasses += ' rounded-2xl';
    if (config.iconShapeBackground === 'hexagon') shapeClasses += ' rounded-xl';

    return (
      <div
        className={shapeClasses}
        style={{
          backgroundColor: `${config.primaryColor}18`,
          border: `1.5px solid ${config.primaryColor}40`,
        }}
      >
        {children}
      </div>
    );
  };

  const renderIcon = () => {
    if (!config.showIcon) return null;

    return renderIconBadgeWrapper(
      <div
        className="flex items-center justify-center transition-transform"
        style={{
          width: `${iconBaseSize}px`,
          height: `${iconBaseSize}px`,
          transform: config.iconRotation ? `rotate(${config.iconRotation}deg)` : undefined,
          color: config.primaryColor,
        }}
      >
        <svg
          viewBox="0 0 100 100"
          className="w-full h-full"
          dangerouslySetInnerHTML={{ __html: config.iconSvg }}
        />
      </div>
    );
  };

  const renderTextGroup = (alignOverride?: 'left' | 'center' | 'right') => {
    const alignment = alignOverride || config.alignment;
    const alignClass =
      alignment === 'center'
        ? 'items-center text-center'
        : alignment === 'right'
        ? 'items-end text-right'
        : 'items-start text-left';

    return (
      <div className={`flex flex-col ${alignClass} justify-center`}>
        <span
          className="leading-none tracking-tight select-none transition-colors"
          style={{
            fontFamily: config.fontFamily,
            fontWeight: config.fontWeight,
            fontSize: `${(config.textSize || 32) * scale}px`,
            letterSpacing: `${(config.letterSpacing || 1) * scale}px`,
            textTransform: config.textTransform,
            color: config.textColor,
          }}
        >
          {config.brandName || 'Brand Name'}
        </span>

        {config.showTagline && config.tagline && (
          <span
            className="mt-1 leading-normal select-none opacity-90 transition-colors"
            style={{
              fontFamily: config.taglineFont,
              fontSize: `${(config.taglineSize || 10) * scale}px`,
              letterSpacing: `${(config.taglineLetterSpacing || 2) * scale}px`,
              textTransform: config.taglineTransform,
              color: config.taglineColor,
              fontWeight: 500,
            }}
          >
            {config.tagline}
          </span>
        )}
      </div>
    );
  };

  const getContainerStyle = (): React.CSSProperties => {
    if (isTransparent) {
      return showTransparentGrid
        ? {
            backgroundImage:
              'radial-gradient(#cbd5e1 1px, transparent 1px), radial-gradient(#cbd5e1 1px, #f8fafc 1px)',
            backgroundSize: '16px 16px',
            backgroundPosition: '0 0, 8px 8px',
          }
        : { backgroundColor: 'transparent' };
    }
    return {
      backgroundColor: config.backgroundColor || '#ffffff',
    };
  };

  return (
    <div
      className={`relative flex items-center justify-center p-6 transition-all duration-300 ${className}`}
      style={getContainerStyle()}
    >
      {isIconOnly && renderIcon()}

      {isHorizontal && (
        <div className="flex items-center gap-5">
          {renderIcon()}
          {renderTextGroup('left')}
        </div>
      )}

      {isVertical && (
        <div className="flex flex-col items-center text-center gap-3">
          {renderIcon()}
          {renderTextGroup('center')}
        </div>
      )}

      {isStacked && (
        <div className="flex flex-col items-center text-center gap-2">
          {renderIcon()}
          {renderTextGroup('center')}
        </div>
      )}

      {isBadge && (
        <div
          className="flex flex-col items-center text-center p-7 rounded-3xl border-2 transition-all shadow-sm"
          style={{
            borderColor: `${config.primaryColor}30`,
            backgroundColor: `${config.primaryColor}08`,
          }}
        >
          <div className="mb-3">{renderIcon()}</div>
          {renderTextGroup('center')}
        </div>
      )}
    </div>
  );
};
