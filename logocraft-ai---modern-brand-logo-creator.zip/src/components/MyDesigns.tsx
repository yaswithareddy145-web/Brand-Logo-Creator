import React, { useState, useEffect } from 'react';
import { LogoConfig } from '../types/logo';
import { getSavedLogos, deleteLogo } from '../utils/storage';
import { LogoRenderer } from './LogoRenderer';
import { downloadPng, downloadSvg } from '../utils/exporter';
import {
  Bookmark,
  ExternalLink,
  Download,
  Trash2,
  AlertTriangle,
  Sparkles,
  Search,
  Plus,
  Layers,
  ChevronDown,
} from 'lucide-react';

interface MyDesignsProps {
  onOpenEditor: (logo: LogoConfig) => void;
  onCreateNew: () => void;
}

export const MyDesigns: React.FC<MyDesignsProps> = ({ onOpenEditor, onCreateNew }) => {
  const [designs, setDesigns] = useState<LogoConfig[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [logoToDelete, setLogoToDelete] = useState<LogoConfig | null>(null);

  const loadDesigns = () => {
    setDesigns(getSavedLogos());
  };

  useEffect(() => {
    loadDesigns();
  }, []);

  const confirmDelete = () => {
    if (logoToDelete) {
      deleteLogo(logoToDelete.id);
      setLogoToDelete(null);
      loadDesigns();
    }
  };

  const filteredDesigns = designs.filter(
    (d) =>
      d.brandName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.tagline.toLowerCase().includes(searchTerm.toLowerCase()) ||
      d.industry.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-8 border-b border-slate-200">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-indigo-50 text-indigo-700 text-xs font-semibold mb-2">
            <Bookmark className="w-3.5 h-3.5" />
            Saved Brand Workspace
          </div>
          <h1 className="text-3xl font-extrabold text-slate-900 tracking-tight">My Logo Projects</h1>
          <p className="text-slate-500 text-sm mt-1">
            Reopen, customize, export vector SVGs, and inspect mockups for your saved logos.
          </p>
        </div>

        <button
          onClick={onCreateNew}
          className="self-start sm:self-auto px-5 py-3 rounded-2xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs sm:text-sm shadow-md shadow-indigo-500/20 transition active:scale-95 flex items-center gap-2"
        >
          <Plus className="w-4 h-4" />
          <span>Create New Logo</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="my-6 flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search saved designs..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl border border-slate-200 text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 bg-white"
          />
        </div>

        <div className="text-xs text-slate-500 font-medium">
          Showing <span className="font-bold text-slate-800">{filteredDesigns.length}</span> saved{' '}
          {filteredDesigns.length === 1 ? 'identity' : 'identities'}
        </div>
      </div>

      {/* Empty State */}
      {filteredDesigns.length === 0 ? (
        <div className="bg-white rounded-3xl border border-dashed border-slate-300 p-12 text-center max-w-lg mx-auto my-8">
          <div className="w-14 h-14 rounded-2xl bg-indigo-50 text-indigo-600 flex items-center justify-center mx-auto mb-4">
            <Layers className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-slate-900 mb-1">No Saved Designs Found</h3>
          <p className="text-xs text-slate-500 mb-6 leading-relaxed">
            {searchTerm
              ? `No logos matched "${searchTerm}". Try a different search query.`
              : 'You have not saved any brand logos yet. Create a logo in the studio and save it here.'}
          </p>
          <button
            onClick={onCreateNew}
            className="px-5 py-2.5 rounded-xl bg-indigo-600 text-white text-xs font-bold hover:bg-indigo-700 transition"
          >
            Launch Logo Creator
          </button>
        </div>
      ) : (
        /* Grid of Saved Logos */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredDesigns.map((design) => (
            <div
              key={design.id}
              className="group bg-white rounded-3xl border border-slate-200/90 hover:border-indigo-300 shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden"
            >
              {/* Card Header */}
              <div className="p-4 px-5 flex items-center justify-between border-b border-slate-100 bg-slate-50/50">
                <div>
                  <h3 className="text-sm font-bold text-slate-900">{design.brandName}</h3>
                  <div className="flex items-center gap-2 mt-0.5">
                    <span className="text-[10px] uppercase font-semibold text-indigo-600">
                      {design.industry}
                    </span>
                    <span className="text-slate-300">•</span>
                    <span className="text-[10px] text-slate-400">{design.style}</span>
                  </div>
                </div>

                <button
                  onClick={() => setLogoToDelete(design)}
                  className="p-2 rounded-xl text-slate-400 hover:text-rose-600 hover:bg-rose-50 transition"
                  title="Delete design"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>

              {/* Render Area */}
              <div
                onClick={() => onOpenEditor(design)}
                className="cursor-pointer p-8 flex items-center justify-center min-h-[220px] bg-white group-hover:bg-slate-50/30 transition"
              >
                <LogoRenderer config={design} scale={0.8} />
              </div>

              {/* Card Footer Actions */}
              <div className="p-4 px-5 border-t border-slate-100 bg-slate-50/80 flex items-center justify-between gap-2">
                <button
                  onClick={() => onOpenEditor(design)}
                  className="px-3.5 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-xs"
                >
                  <span>Edit in Studio</span>
                  <ExternalLink className="w-3 h-3" />
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => downloadSvg(design, false)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-semibold text-slate-700 flex items-center gap-1"
                    title="Download SVG vector"
                  >
                    <Download className="w-3 h-3" />
                    SVG
                  </button>

                  <button
                    onClick={() => downloadPng(design, true)}
                    className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white hover:bg-slate-100 text-[11px] font-semibold text-slate-700 flex items-center gap-1"
                    title="Download Transparent PNG"
                  >
                    <Download className="w-3 h-3" />
                    PNG
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Delete Confirmation Modal */}
      {logoToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/50 backdrop-blur-xs p-4 animate-in fade-in">
          <div className="bg-white rounded-3xl p-6 max-w-sm w-full shadow-2xl border border-slate-200 text-center">
            <div className="w-12 h-12 rounded-full bg-rose-50 text-rose-600 flex items-center justify-center mx-auto mb-4">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <h3 className="text-base font-bold text-slate-900 mb-1">Delete Saved Logo?</h3>
            <p className="text-xs text-slate-500 mb-6 leading-relaxed">
              Are you sure you want to delete <span className="font-bold text-slate-800">"{logoToDelete.brandName}"</span>?
              This action cannot be undone.
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => setLogoToDelete(null)}
                className="py-2.5 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="py-2.5 rounded-xl bg-rose-600 hover:bg-rose-700 text-white text-xs font-bold transition shadow-sm"
              >
                Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
