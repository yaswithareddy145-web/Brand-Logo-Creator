import React, { useState } from 'react';
import { LogoConfig, MockupType } from '../types/logo';
import { LogoRenderer } from './LogoRenderer';
import { 
  CreditCard, 
  Shirt, 
  Package, 
  Store, 
  Globe, 
  Layers, 
  Download, 
  Sparkles,
  CheckCircle2,
  Share2
} from 'lucide-react';
import { downloadPng } from '../utils/exporter';

interface MockupPreviewProps {
  logo: LogoConfig;
}

export const MockupPreview: React.FC<MockupPreviewProps> = ({ logo }) => {
  const [activeMockup, setActiveMockup] = useState<MockupType | 'all'>('business-card');
  const [cardTheme, setCardTheme] = useState<'dark' | 'light' | 'brand'>('light');

  // Business Card Mockup
  const renderBusinessCard = () => {
    const isDark = cardTheme === 'dark';
    const isBrand = cardTheme === 'brand';

    const cardBg = isDark ? '#0f172a' : isBrand ? logo.primaryColor : '#ffffff';
    const textColor = isDark || isBrand ? '#f8fafc' : '#1e293b';
    const subtextColor = isDark || isBrand ? '#94a3b8' : '#64748b';
    const borderColor = isDark ? '#334155' : isBrand ? `${logo.secondaryColor}40` : '#e2e8f0';

    return (
      <div className="relative w-full max-w-2xl mx-auto py-12 px-6 flex flex-col items-center justify-center">
        {/* Shadow floor */}
        <div className="absolute inset-0 bg-gradient-to-br from-slate-100 via-purple-50/30 to-blue-50/40 rounded-3xl" />
        
        {/* 3D angled business card container */}
        <div className="relative z-10 w-full flex flex-col md:flex-row items-center justify-center gap-8">
          {/* Card Front */}
          <div
            className="w-80 h-48 rounded-2xl p-6 shadow-2xl flex flex-col justify-between transition-all duration-300 transform hover:-translate-y-1 hover:rotate-1"
            style={{
              backgroundColor: cardBg,
              border: `1px solid ${borderColor}`,
              boxShadow: '0 25px 50px -12px rgba(15, 23, 42, 0.25)',
            }}
          >
            <div className="flex justify-between items-start">
              <span className="text-[10px] uppercase font-bold tracking-widest opacity-60" style={{ color: subtextColor }}>
                Premium Corporate
              </span>
              <div className="w-4 h-4 rounded-full border" style={{ borderColor: subtextColor, opacity: 0.4 }} />
            </div>

            <div className="my-auto py-2">
              <LogoRenderer
                config={{
                  ...logo,
                  hasTransparentBg: true,
                  textColor: isDark || isBrand ? '#ffffff' : logo.textColor,
                  taglineColor: isDark || isBrand ? '#cbd5e1' : logo.taglineColor,
                }}
                scale={0.7}
              />
            </div>

            <div className="flex justify-between items-end text-[10px]" style={{ color: subtextColor }}>
              <span>www.{logo.brandName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com</span>
              <span className="font-mono">#084-BC</span>
            </div>
          </div>

          {/* Card Back / Executive Info */}
          <div
            className="w-80 h-48 rounded-2xl p-6 shadow-xl flex flex-col justify-between transition-all duration-300 transform hover:-translate-y-1 hover:-rotate-1"
            style={{
              backgroundColor: isDark ? '#1e293b' : '#f8fafc',
              border: `1px solid ${borderColor}`,
              boxShadow: '0 20px 40px -15px rgba(0,0,0,0.15)',
            }}
          >
            <div>
              <h4 className="font-bold text-base tracking-tight" style={{ color: isDark ? '#ffffff' : '#0f172a' }}>
                Alexander Hayes
              </h4>
              <p className="text-xs font-medium" style={{ color: logo.primaryColor }}>
                Founder & Chief Executive Officer
              </p>
            </div>

            <div className="space-y-1 text-xs" style={{ color: subtextColor }}>
              <div className="flex items-center gap-2">
                <span>✉</span>
                <span>alexander@{logo.brandName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com</span>
              </div>
              <div className="flex items-center gap-2">
                <span>✆</span>
                <span>+1 (555) 234-8900</span>
              </div>
              <div className="flex items-center gap-2">
                <span>📍</span>
                <span>500 Innovation Way, Suite 1200</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t" style={{ borderColor: isDark ? '#334155' : '#e2e8f0' }}>
              <span className="text-[10px] font-semibold tracking-wider uppercase" style={{ color: logo.primaryColor }}>
                {logo.brandName}
              </span>
              <div className="w-5 h-5 rounded bg-slate-300/40 flex items-center justify-center text-[8px] font-mono">
                QR
              </div>
            </div>
          </div>
        </div>

        {/* Card Theme Switcher */}
        <div className="relative z-10 mt-6 flex items-center gap-3 bg-white/80 backdrop-blur px-4 py-2 rounded-full border border-slate-200 shadow-sm text-xs">
          <span className="text-slate-500 font-medium">Card Finish:</span>
          <button
            onClick={() => setCardTheme('light')}
            className={`px-3 py-1 rounded-full font-medium transition ${
              cardTheme === 'light' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pure Linen
          </button>
          <button
            onClick={() => setCardTheme('dark')}
            className={`px-3 py-1 rounded-full font-medium transition ${
              cardTheme === 'dark' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Matte Obsidian
          </button>
          <button
            onClick={() => setCardTheme('brand')}
            className={`px-3 py-1 rounded-full font-medium transition ${
              cardTheme === 'brand' ? 'bg-slate-900 text-white shadow' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Brand Tone
          </button>
        </div>
      </div>
    );
  };

  // T-Shirt Mockup
  const renderTShirt = () => {
    return (
      <div className="relative w-full max-w-2xl mx-auto py-10 px-6 flex flex-col items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-tr from-slate-100 to-indigo-50/50 rounded-3xl" />
        
        {/* Realistic SVG apparel mockup */}
        <div className="relative z-10 w-80 h-96 flex items-center justify-center">
          {/* T-Shirt base shape */}
          <svg viewBox="0 0 300 360" className="w-full h-full drop-shadow-2xl">
            <defs>
              <linearGradient id="teeShade" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#1e293b" />
                <stop offset="50%" stopColor="#0f172a" />
                <stop offset="100%" stopColor="#1e293b" />
              </linearGradient>
              <filter id="fabricTexture">
                <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise" />
                <feColorMatrix type="matrix" values="0 0 0 0 0   0 0 0 0 0   0 0 0 0 0  0 0 0 0.05 0" />
                <feBlend mode="multiply" in="SourceGraphic" result="blend" />
              </filter>
            </defs>
            {/* T-shirt paths */}
            <path
              d="M 90 20 C 115 45, 185 45, 210 20 L 280 60 L 250 120 L 220 100 L 225 340 L 75 340 L 80 100 L 50 120 L 20 60 Z"
              fill="url(#teeShade)"
              stroke="#334155"
              strokeWidth="2"
            />
            {/* Collar line */}
            <path d="M 90 20 C 120 48, 180 48, 210 20 C 185 30, 115 30, 90 20 Z" fill="#334155" />
            {/* Sleeve folds */}
            <path d="M 80 100 L 60 115" stroke="#334155" strokeWidth="2" />
            <path d="M 220 100 L 240 115" stroke="#334155" strokeWidth="2" />
          </svg>

          {/* Logo printed on chest */}
          <div className="absolute top-28 w-44 flex items-center justify-center pointer-events-none transform scale-90">
            <div className="opacity-95 contrast-125">
              <LogoRenderer
                config={{
                  ...logo,
                  hasTransparentBg: true,
                  textColor: '#f8fafc',
                  taglineColor: '#cbd5e1',
                }}
                scale={0.52}
              />
            </div>
          </div>
        </div>

        <p className="relative z-10 mt-4 text-xs text-slate-500 font-medium">
          Screen-printed chest print on heavy 240 GSM organic cotton
        </p>
      </div>
    );
  };

  // Product Packaging Box
  const renderPackaging = () => {
    return (
      <div className="relative w-full max-w-2xl mx-auto py-12 px-6 flex flex-col items-center justify-center">
        <div className="absolute inset-0 bg-gradient-to-b from-slate-100 to-amber-50/30 rounded-3xl" />
        
        {/* Isometric 3D Box */}
        <div className="relative z-10 w-96 h-80 flex items-center justify-center">
          <svg viewBox="0 0 400 320" className="w-full h-full drop-shadow-2xl">
            <defs>
              <linearGradient id="boxTop" x1="0" y1="0" x2="1" y2="1">
                <stop offset="0%" stopColor="#ffffff" />
                <stop offset="100%" stopColor="#f1f5f9" />
              </linearGradient>
              <linearGradient id="boxLeft" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#e2e8f0" />
                <stop offset="100%" stopColor="#cbd5e1" />
              </linearGradient>
              <linearGradient id="boxRight" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#f8fafc" />
                <stop offset="100%" stopColor="#e2e8f0" />
              </linearGradient>
            </defs>

            {/* Top Face */}
            <polygon points="200,40 340,110 200,180 60,110" fill="url(#boxTop)" stroke="#cbd5e1" strokeWidth="2" />
            {/* Left Face */}
            <polygon points="60,110 200,180 200,300 60,230" fill="url(#boxLeft)" stroke="#94a3b8" strokeWidth="2" />
            {/* Right Face */}
            <polygon points="200,180 340,110 340,230 200,300" fill="url(#boxRight)" stroke="#cbd5e1" strokeWidth="2" />

            {/* Tape / Seal */}
            <polygon points="180,50 220,70 220,190 180,170" fill={logo.primaryColor} fillOpacity="0.85" />
          </svg>

          {/* Logo on box front right face */}
          <div
            className="absolute right-12 top-28 w-44 pointer-events-none transform -skew-y-12 rotate-3"
            style={{ filter: 'drop-shadow(0 2px 4px rgba(0,0,0,0.1))' }}
          >
            <LogoRenderer
              config={{
                ...logo,
                hasTransparentBg: true,
              }}
              scale={0.5}
            />
          </div>
        </div>

        <div className="relative z-10 flex items-center gap-6 mt-3 text-xs text-slate-500">
          <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Recycled Kraft Packaging</span>
          <span className="flex items-center gap-1.5"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" /> Foil Stamp Ready</span>
        </div>
      </div>
    );
  };

  // Storefront Sign Mockup
  const renderStorefront = () => {
    return (
      <div className="relative w-full max-w-2xl mx-auto py-10 px-6 flex flex-col items-center justify-center">
        <div className="relative z-10 w-full bg-slate-900 rounded-3xl overflow-hidden p-8 border border-slate-800 shadow-2xl">
          {/* Architectural facade top molding */}
          <div className="w-full h-4 bg-slate-800 rounded-t-lg mb-6 border-b border-slate-700" />

          {/* Sconces / Downlights */}
          <div className="flex justify-between px-16 mb-4">
            <div className="relative flex flex-col items-center">
              <div className="w-6 h-3 bg-amber-400 rounded-t-full shadow-lg" />
              <div className="w-24 h-32 bg-gradient-to-b from-amber-300/30 to-transparent blur-md pointer-events-none" />
            </div>
            <div className="relative flex flex-col items-center">
              <div className="w-6 h-3 bg-amber-400 rounded-t-full shadow-lg" />
              <div className="w-24 h-32 bg-gradient-to-b from-amber-300/30 to-transparent blur-md pointer-events-none" />
            </div>
          </div>

          {/* Main 3D Sign Board */}
          <div className="relative bg-slate-950/80 backdrop-blur border border-slate-700/80 rounded-2xl p-8 flex flex-col items-center justify-center shadow-[inset_0_2px_10px_rgba(255,255,255,0.05)]">
            <div className="relative z-10">
              <LogoRenderer
                config={{
                  ...logo,
                  hasTransparentBg: true,
                  textColor: '#ffffff',
                  taglineColor: '#94a3b8',
                }}
                scale={0.9}
              />
            </div>
            {/* Subtle glow behind logo */}
            <div
              className="absolute inset-0 rounded-2xl opacity-20 blur-xl pointer-events-none"
              style={{ backgroundColor: logo.primaryColor }}
            />
          </div>

          {/* Store entrance glass hint below */}
          <div className="mt-8 flex justify-center gap-4 border-t border-slate-800 pt-6">
            <div className="w-28 h-20 bg-slate-800/40 border border-slate-700/50 rounded-t-lg" />
            <div className="w-28 h-20 bg-slate-800/40 border border-slate-700/50 rounded-t-lg" />
          </div>
        </div>
      </div>
    );
  };

  // Website Header Mockup
  const renderWebsiteHeader = () => {
    return (
      <div className="relative w-full max-w-2xl mx-auto py-8 px-6 flex flex-col items-center justify-center">
        {/* Browser Frame */}
        <div className="w-full bg-white rounded-2xl border border-slate-200 shadow-2xl overflow-hidden">
          {/* Browser Top Bar */}
          <div className="bg-slate-100 px-4 py-3 border-b border-slate-200 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="w-3 h-3 rounded-full bg-rose-400" />
              <div className="w-3 h-3 rounded-full bg-amber-400" />
              <div className="w-3 h-3 rounded-full bg-emerald-400" />
            </div>

            <div className="flex items-center gap-2 bg-white px-4 py-1 rounded-md border border-slate-200 text-[11px] text-slate-500 w-1/2 justify-center font-mono">
              <span className="text-slate-400">🔒</span>
              <span>https://www.{logo.brandName.toLowerCase().replace(/[^a-z0-9]/g, '')}.com</span>
            </div>

            <div className="w-12" />
          </div>

          {/* App Header Navigation */}
          <div className="px-6 py-4 border-b border-slate-100 flex items-center justify-between bg-white">
            <div className="flex items-center">
              <LogoRenderer
                config={{
                  ...logo,
                  layout: 'horizontal',
                  hasTransparentBg: true,
                  textSize: 22,
                  taglineSize: 0,
                  showTagline: false,
                  iconSize: 32,
                }}
                scale={0.65}
              />
            </div>

            <div className="hidden sm:flex items-center gap-6 text-xs font-medium text-slate-600">
              <span className="text-slate-900 font-semibold">Products</span>
              <span>Solutions</span>
              <span>Company</span>
              <span>Pricing</span>
            </div>

            <div className="flex items-center gap-3">
              <button
                className="text-xs px-3.5 py-1.5 rounded-lg font-medium text-white shadow-sm"
                style={{ backgroundColor: logo.primaryColor }}
              >
                Get Started
              </button>
            </div>
          </div>

          {/* Hero Content simulation */}
          <div className="p-8 text-center bg-gradient-to-b from-slate-50 to-white">
            <div
              className="inline-flex items-center gap-2 px-3 py-1 rounded-full text-[11px] font-medium mb-3"
              style={{ backgroundColor: `${logo.primaryColor}15`, color: logo.primaryColor }}
            >
              <Sparkles className="w-3 h-3" />
              Welcome to the next evolution of {logo.industry}
            </div>
            <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight">
              Empowering {logo.brandName} with Intelligent Workflows
            </h3>
            <p className="mt-2 text-xs text-slate-500 max-w-md mx-auto">
              {logo.tagline || 'Transforming brand operations with speed, reliability, and precision.'}
            </p>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full bg-white rounded-3xl border border-slate-200/80 shadow-sm p-6 sm:p-8">
      {/* Header and mockup navigation */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
        <div>
          <h3 className="text-lg font-bold text-slate-900 flex items-center gap-2">
            <Layers className="w-5 h-5 text-indigo-600" />
            Brand Mockup Showcase
          </h3>
          <p className="text-xs text-slate-500 mt-0.5">
            Visualize how your logo behaves across high-impact physical and digital touchpoints.
          </p>
        </div>

        {/* Tab buttons */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100/90 rounded-2xl border border-slate-200/60">
          <button
            onClick={() => setActiveMockup('business-card')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition ${
              activeMockup === 'business-card'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <CreditCard className="w-3.5 h-3.5" />
            Stationery
          </button>

          <button
            onClick={() => setActiveMockup('t-shirt')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition ${
              activeMockup === 't-shirt'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Shirt className="w-3.5 h-3.5" />
            Apparel
          </button>

          <button
            onClick={() => setActiveMockup('product-packaging')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition ${
              activeMockup === 'product-packaging'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Package className="w-3.5 h-3.5" />
            Packaging
          </button>

          <button
            onClick={() => setActiveMockup('storefront')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition ${
              activeMockup === 'storefront'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Store className="w-3.5 h-3.5" />
            Storefront
          </button>

          <button
            onClick={() => setActiveMockup('website-header')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition ${
              activeMockup === 'website-header'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Globe className="w-3.5 h-3.5" />
            Website
          </button>

          <button
            onClick={() => setActiveMockup('all')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition ${
              activeMockup === 'all'
                ? 'bg-white text-indigo-600 shadow-sm'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            All Views
          </button>
        </div>
      </div>

      {/* Main Mockup Area */}
      <div className="mt-6">
        {activeMockup === 'business-card' && renderBusinessCard()}
        {activeMockup === 't-shirt' && renderTShirt()}
        {activeMockup === 'product-packaging' && renderPackaging()}
        {activeMockup === 'storefront' && renderStorefront()}
        {activeMockup === 'website-header' && renderWebsiteHeader()}

        {activeMockup === 'all' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Corporate Stationery</h4>
              {renderBusinessCard()}
            </div>
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Screenprinted Apparel</h4>
              {renderTShirt()}
            </div>
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Retail Packaging</h4>
              {renderPackaging()}
            </div>
            <div className="bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Storefront Signage</h4>
              {renderStorefront()}
            </div>
            <div className="lg:col-span-2 bg-slate-50 rounded-2xl p-4 border border-slate-200">
              <h4 className="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Digital App Presence</h4>
              {renderWebsiteHeader()}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
