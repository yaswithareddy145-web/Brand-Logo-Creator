import React, { useState, useEffect } from 'react';
import { LogoConfig, LogoLayout, TextAlignment } from '../types/logo';
import { LogoRenderer } from './LogoRenderer';
import { MockupPreview } from './MockupPreview';
import {
  FONT_OPTIONS,
  COLOR_PALETTES,
  ICON_LIBRARY,
} from '../utils/logoTemplates';
import { downloadPng, downloadSvg, copySvgCode } from '../utils/exporter';
import { saveLogo } from '../utils/storage';
import {
  Type,
  Palette,
  Layout,
  Sliders,
  Download,
  RotateCcw,
  Undo2,
  Check,
  Bookmark,
  Eye,
  FileCode,
  Sparkles,
  Grid,
  AlignLeft,
  AlignCenter,
  AlignRight,
  Maximize2,
  Image as ImageIcon,
  Layers,
  ChevronDown
} from 'lucide-react';

interface LogoEditorProps {
  initialLogo: LogoConfig;
  onBackToStudio?: () => void;
  onSaved?: (logo: LogoConfig) => void;
}

export const LogoEditor: React.FC<LogoEditorProps> = ({
  initialLogo,
  onBackToStudio,
  onSaved,
}) => {
  // Current logo state
  const [logo, setLogo] = useState<LogoConfig>(initialLogo);
  // History stack for Undo
  const [history, setHistory] = useState<LogoConfig[]>([initialLogo]);
  // Active editing tab
  const [activeTab, setActiveTab] = useState<'text' | 'icon' | 'colors' | 'layout' | 'mockups'>('text');
  
  // UI states
  const [isSaved, setIsSaved] = useState(false);
  const [copiedCode, setCopiedCode] = useState(false);
  const [showGrid, setShowGrid] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [scale, setScale] = useState(1);

  // Sync when initial logo prop changes
  useEffect(() => {
    setLogo(initialLogo);
    setHistory([initialLogo]);
  }, [initialLogo.id]);

  // Push to history when making changes
  const updateLogo = (updater: (prev: LogoConfig) => LogoConfig) => {
    setLogo((prev) => {
      const next = updater(prev);
      setHistory((hist) => [...hist.slice(-20), next]);
      setIsSaved(false);
      return next;
    });
  };

  const handleUndo = () => {
    if (history.length > 1) {
      const newHistory = history.slice(0, -1);
      const prevLogo = newHistory[newHistory.length - 1];
      setHistory(newHistory);
      setLogo(prevLogo);
      setIsSaved(false);
    }
  };

  const handleReset = () => {
    setLogo(initialLogo);
    setHistory([initialLogo]);
    setIsSaved(false);
  };

  const handleSave = () => {
    saveLogo(logo);
    setIsSaved(true);
    if (onSaved) onSaved(logo);
    setTimeout(() => setIsSaved(false), 2500);
  };

  const handleCopySvg = async () => {
    await copySvgCode(logo, logo.hasTransparentBg);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  const handleDownloadPng = async (transparent: boolean) => {
    setIsDownloading(true);
    try {
      await downloadPng(logo, transparent, 2);
    } finally {
      setIsDownloading(false);
    }
  };

  return (
    <div className="w-full flex flex-col min-h-screen bg-slate-50/60 pb-16">
      {/* Top action header */}
      <div className="sticky top-16 z-30 bg-white/95 backdrop-blur border-b border-slate-200/80 px-4 sm:px-8 py-3.5 transition-all shadow-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            {onBackToStudio && (
              <button
                onClick={onBackToStudio}
                className="px-3 py-1.5 rounded-xl text-xs font-semibold text-slate-600 hover:text-slate-900 hover:bg-slate-100 transition"
              >
                ← Studio
              </button>
            )}
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-sm sm:text-base font-bold text-slate-900 tracking-tight">
                  {logo.brandName || 'Untitled Brand'}
                </h2>
                <span className="text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full bg-indigo-50 text-indigo-600 border border-indigo-100">
                  {logo.style}
                </span>
              </div>
              <p className="text-[11px] text-slate-500 hidden sm:block">
                {logo.conceptName || 'Custom Brand Mark'}
              </p>
            </div>
          </div>

          {/* Quick history & actions */}
          <div className="flex items-center gap-2">
            <button
              onClick={handleUndo}
              disabled={history.length <= 1}
              className={`p-2 rounded-xl text-slate-600 border border-slate-200 transition ${
                history.length <= 1 ? 'opacity-40 cursor-not-allowed' : 'hover:bg-slate-100'
              }`}
              title="Undo last change"
            >
              <Undo2 className="w-4 h-4" />
            </button>

            <button
              onClick={handleReset}
              className="p-2 rounded-xl text-slate-600 border border-slate-200 hover:bg-slate-100 transition"
              title="Reset to original design"
            >
              <RotateCcw className="w-4 h-4" />
            </button>

            <div className="h-5 w-px bg-slate-200 mx-1 hidden sm:block" />

            {/* Save Button */}
            <button
              onClick={handleSave}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-xl text-xs font-semibold transition shadow-sm ${
                isSaved
                  ? 'bg-emerald-600 text-white'
                  : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              {isSaved ? <Check className="w-3.5 h-3.5" /> : <Bookmark className="w-3.5 h-3.5 text-indigo-600" />}
              {isSaved ? 'Saved!' : 'Save Design'}
            </button>

            {/* Copy SVG code */}
            <button
              onClick={handleCopySvg}
              className="hidden md:flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-medium text-slate-600 border border-slate-200 hover:bg-slate-50 transition"
              title="Copy SVG code to clipboard"
            >
              {copiedCode ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <FileCode className="w-3.5 h-3.5" />}
              {copiedCode ? 'Copied SVG' : 'Copy SVG'}
            </button>

            {/* Download Dropdown */}
            <div className="relative group">
              <button
                disabled={isDownloading}
                className="flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-md shadow-indigo-500/20 transition active:scale-95"
              >
                <Download className="w-3.5 h-3.5" />
                <span>Export Logo</span>
                <ChevronDown className="w-3.5 h-3.5 opacity-70" />
              </button>

              <div className="absolute right-0 top-full mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 p-2 hidden group-hover:block z-50 animate-in fade-in slide-in-from-top-1">
                <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Vector Formats
                </div>
                <button
                  onClick={() => downloadSvg(logo, false)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center justify-between"
                >
                  <span>Vector SVG (.svg)</span>
                  <span className="text-[10px] text-indigo-600 font-semibold">Print/Web</span>
                </button>
                <button
                  onClick={() => downloadSvg(logo, true)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center justify-between"
                >
                  <span>Transparent SVG (.svg)</span>
                  <span className="text-[10px] text-slate-400">Pure Icon</span>
                </button>

                <div className="my-1 border-t border-slate-100" />
                <div className="px-3 py-1.5 text-[10px] font-bold text-slate-400 uppercase tracking-wider">
                  Bitmap Images
                </div>
                <button
                  onClick={() => handleDownloadPng(false)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center justify-between"
                >
                  <span>High-Res PNG (2400px)</span>
                  <span className="text-[10px] text-purple-600 font-semibold">HQ</span>
                </button>
                <button
                  onClick={() => handleDownloadPng(true)}
                  className="w-full text-left px-3 py-2 text-xs font-medium text-slate-700 hover:bg-slate-50 rounded-xl flex items-center justify-between"
                >
                  <span>Transparent PNG</span>
                  <span className="text-[10px] text-emerald-600 font-semibold">Clean</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Studio Workspace */}
      <div className="max-w-7xl mx-auto w-full px-4 sm:px-8 mt-6">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Left Canvas Preview Area (7 Cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4">
            {/* Canvas Stage */}
            <div className="relative w-full bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col min-h-[440px] sm:min-h-[500px]">
              {/* Canvas controls top bar */}
              <div className="p-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                <div className="flex items-center gap-1.5">
                  <button
                    onClick={() => setShowGrid(!showGrid)}
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                      showGrid
                        ? 'bg-indigo-50 text-indigo-600 border border-indigo-200'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                    title="Toggle checkered transparency background"
                  >
                    <Grid className="w-3.5 h-3.5" />
                    Grid
                  </button>

                  <button
                    onClick={() =>
                      updateLogo((prev) => ({
                        ...prev,
                        hasTransparentBg: !prev.hasTransparentBg,
                      }))
                    }
                    className={`flex items-center gap-1 px-2.5 py-1 rounded-lg text-xs font-medium transition ${
                      logo.hasTransparentBg
                        ? 'bg-purple-50 text-purple-600 border border-purple-200'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    <Eye className="w-3.5 h-3.5" />
                    Transparent
                  </button>
                </div>

                {/* Scale buttons */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setScale((s) => Math.max(0.6, s - 0.1))}
                    className="w-6 h-6 rounded-md bg-white border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50"
                  >
                    -
                  </button>
                  <span className="text-[11px] font-mono text-slate-500 w-10 text-center">
                    {Math.round(scale * 100)}%
                  </span>
                  <button
                    onClick={() => setScale((s) => Math.min(1.4, s + 0.1))}
                    className="w-6 h-6 rounded-md bg-white border border-slate-200 text-xs font-bold text-slate-600 hover:bg-slate-50"
                  >
                    +
                  </button>
                </div>
              </div>

              {/* Live Render Stage */}
              <div className="relative flex-1 flex items-center justify-center p-8 sm:p-12 overflow-hidden min-h-[360px]">
                <LogoRenderer
                  config={logo}
                  scale={scale}
                  showTransparentGrid={showGrid}
                  className="rounded-2xl transition-all"
                />
              </div>

              {/* Canvas bottom rationale note */}
              {logo.rationale && (
                <div className="p-4 bg-slate-50/80 border-t border-slate-100 flex items-start gap-2 text-xs text-slate-600">
                  <Sparkles className="w-4 h-4 text-indigo-500 shrink-0 mt-0.5" />
                  <div>
                    <span className="font-semibold text-slate-900">Design Psychology: </span>
                    {logo.rationale}
                  </div>
                </div>
              )}
            </div>

            {/* Quick Layout presets bar */}
            <div className="bg-white rounded-2xl border border-slate-200 p-3 flex flex-wrap items-center justify-between gap-2 shadow-xs">
              <span className="text-xs font-bold text-slate-600 px-2 flex items-center gap-1.5">
                <Layout className="w-3.5 h-3.5 text-indigo-600" />
                Quick Layout:
              </span>
              <div className="flex items-center gap-1.5">
                {(['horizontal', 'vertical', 'stacked', 'badge', 'icon-only'] as LogoLayout[]).map((mode) => (
                  <button
                    key={mode}
                    onClick={() => updateLogo((prev) => ({ ...prev, layout: mode }))}
                    className={`px-3 py-1.5 rounded-xl text-xs font-medium capitalize transition ${
                      logo.layout === mode
                        ? 'bg-slate-900 text-white shadow-xs'
                        : 'text-slate-600 hover:bg-slate-100'
                    }`}
                  >
                    {mode.replace('-', ' ')}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Editing Sidebar (5 Cols) */}
          <div className="lg:col-span-5 bg-white rounded-3xl border border-slate-200/90 shadow-sm overflow-hidden flex flex-col">
            {/* Tab navigation */}
            <div className="flex border-b border-slate-200 overflow-x-auto no-scrollbar bg-slate-50/60 p-1.5 gap-1">
              <button
                onClick={() => setActiveTab('text')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap ${
                  activeTab === 'text'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Type className="w-3.5 h-3.5" />
                Text & Fonts
              </button>

              <button
                onClick={() => setActiveTab('icon')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap ${
                  activeTab === 'icon'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                Icon & Mark
              </button>

              <button
                onClick={() => setActiveTab('colors')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap ${
                  activeTab === 'colors'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Palette className="w-3.5 h-3.5" />
                Colors
              </button>

              <button
                onClick={() => setActiveTab('layout')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap ${
                  activeTab === 'layout'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Layout className="w-3.5 h-3.5" />
                Align & Style
              </button>

              <button
                onClick={() => setActiveTab('mockups')}
                className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-semibold transition whitespace-nowrap ${
                  activeTab === 'mockups'
                    ? 'bg-white text-indigo-600 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                Mockups
              </button>
            </div>

            {/* Tab Panels */}
            <div className="p-6 overflow-y-auto max-h-[580px] space-y-6">
              {/* TAB 1: TEXT & FONTS */}
              {activeTab === 'text' && (
                <div className="space-y-5">
                  {/* Brand Name Input */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Brand / Company Name
                    </label>
                    <input
                      type="text"
                      value={logo.brandName}
                      onChange={(e) => updateLogo((prev) => ({ ...prev, brandName: e.target.value }))}
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500"
                      placeholder="e.g. Lumina Labs"
                    />
                  </div>

                  {/* Tagline Input & Toggle */}
                  <div>
                    <div className="flex items-center justify-between mb-1.5">
                      <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                        Tagline (Optional)
                      </label>
                      <button
                        onClick={() => updateLogo((prev) => ({ ...prev, showTagline: !prev.showTagline }))}
                        className={`text-[11px] font-semibold ${
                          logo.showTagline ? 'text-indigo-600' : 'text-slate-400'
                        }`}
                      >
                        {logo.showTagline ? 'Enabled' : 'Hidden'}
                      </button>
                    </div>
                    <input
                      type="text"
                      value={logo.tagline}
                      onChange={(e) =>
                        updateLogo((prev) => ({
                          ...prev,
                          tagline: e.target.value,
                          showTagline: true,
                        }))
                      }
                      className="w-full px-3.5 py-2.5 rounded-xl border border-slate-200 text-sm text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500"
                      placeholder="e.g. Autonomous Intelligence"
                    />
                  </div>

                  {/* Font Family Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Brand Typography Font
                    </label>
                    <div className="grid grid-cols-1 gap-2 max-h-48 overflow-y-auto pr-1">
                      {FONT_OPTIONS.map((f) => (
                        <button
                          key={f.name}
                          onClick={() => updateLogo((prev) => ({ ...prev, fontFamily: f.value }))}
                          className={`flex items-center justify-between px-3.5 py-2 rounded-xl text-left border transition ${
                            logo.fontFamily === f.value
                              ? 'border-indigo-600 bg-indigo-50/50 text-indigo-900 font-bold'
                              : 'border-slate-200 hover:border-slate-300 text-slate-700'
                          }`}
                        >
                          <span style={{ fontFamily: f.value }} className="text-sm">
                            {f.name}
                          </span>
                          <span className="text-[10px] text-slate-400 uppercase tracking-wider">
                            {f.category}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Brand Text Size Slider */}
                  <div>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="font-semibold text-slate-700">Text Size</span>
                      <span className="font-mono text-slate-500">{logo.textSize}px</span>
                    </div>
                    <input
                      type="range"
                      min={20}
                      max={60}
                      value={logo.textSize}
                      onChange={(e) => updateLogo((prev) => ({ ...prev, textSize: Number(e.target.value) }))}
                      className="w-full accent-indigo-600"
                    />
                  </div>

                  {/* Letter Spacing */}
                  <div>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="font-semibold text-slate-700">Letter Spacing</span>
                      <span className="font-mono text-slate-500">{logo.letterSpacing}px</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={12}
                      step={0.5}
                      value={logo.letterSpacing}
                      onChange={(e) => updateLogo((prev) => ({ ...prev, letterSpacing: Number(e.target.value) }))}
                      className="w-full accent-indigo-600"
                    />
                  </div>

                  {/* Text Transform */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                      Capitalization
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      {(['uppercase', 'capitalize', 'none'] as const).map((mode) => (
                        <button
                          key={mode}
                          onClick={() => updateLogo((prev) => ({ ...prev, textTransform: mode }))}
                          className={`py-1.5 text-xs font-semibold rounded-xl border capitalize transition ${
                            logo.textTransform === mode
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                              : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          {mode}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: ICON & SYMBOL */}
              {activeTab === 'icon' && (
                <div className="space-y-5">
                  <div className="flex items-center justify-between">
                    <label className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Show Logo Icon
                    </label>
                    <input
                      type="checkbox"
                      checked={logo.showIcon}
                      onChange={(e) => updateLogo((prev) => ({ ...prev, showIcon: e.target.checked }))}
                      className="w-4 h-4 accent-indigo-600 rounded"
                    />
                  </div>

                  {/* Icon Library Selector */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Select Vector Symbol
                    </label>
                    <div className="grid grid-cols-4 gap-2.5 max-h-52 overflow-y-auto pr-1">
                      {ICON_LIBRARY.map((item) => (
                        <button
                          key={item.id}
                          onClick={() => updateLogo((prev) => ({ ...prev, iconSvg: item.paths, showIcon: true }))}
                          className={`aspect-square p-2 rounded-2xl border flex flex-col items-center justify-center transition group ${
                            logo.iconSvg === item.paths
                              ? 'border-indigo-600 bg-indigo-50/70 text-indigo-600'
                              : 'border-slate-200 hover:border-slate-300 text-slate-700 hover:bg-slate-50'
                          }`}
                          title={item.name}
                        >
                          <svg
                            viewBox="0 0 100 100"
                            className="w-7 h-7"
                            dangerouslySetInnerHTML={{ __html: item.paths }}
                          />
                          <span className="text-[9px] mt-1 text-slate-500 truncate w-full text-center">
                            {item.name}
                          </span>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Icon Size Slider */}
                  <div>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="font-semibold text-slate-700">Icon Size</span>
                      <span className="font-mono text-slate-500">{logo.iconSize}px</span>
                    </div>
                    <input
                      type="range"
                      min={24}
                      max={90}
                      value={logo.iconSize}
                      onChange={(e) => updateLogo((prev) => ({ ...prev, iconSize: Number(e.target.value) }))}
                      className="w-full accent-indigo-600"
                    />
                  </div>

                  {/* Icon Rotation */}
                  <div>
                    <div className="flex justify-between items-center text-xs mb-1">
                      <span className="font-semibold text-slate-700">Rotation</span>
                      <span className="font-mono text-slate-500">{logo.iconRotation || 0}°</span>
                    </div>
                    <input
                      type="range"
                      min={0}
                      max={360}
                      step={15}
                      value={logo.iconRotation || 0}
                      onChange={(e) => updateLogo((prev) => ({ ...prev, iconRotation: Number(e.target.value) }))}
                      className="w-full accent-indigo-600"
                    />
                  </div>

                  {/* Icon Container Shape */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Emblem Frame / Badge Shape
                    </label>
                    <div className="grid grid-cols-4 gap-2">
                      {(['none', 'circle', 'rounded', 'hexagon'] as const).map((shape) => (
                        <button
                          key={shape}
                          onClick={() => updateLogo((prev) => ({ ...prev, iconShapeBackground: shape }))}
                          className={`py-2 text-xs font-semibold rounded-xl border capitalize transition ${
                            (logo.iconShapeBackground || 'none') === shape
                              ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                              : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          {shape}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 3: COLORS */}
              {activeTab === 'colors' && (
                <div className="space-y-5">
                  {/* Preset Palettes */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Preset Color Harmonies
                    </label>
                    <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                      {COLOR_PALETTES.map((pal) => (
                        <button
                          key={pal.id}
                          onClick={() =>
                            updateLogo((prev) => ({
                              ...prev,
                              primaryColor: pal.primary,
                              secondaryColor: pal.secondary,
                              accentColor: pal.accent,
                              textColor: pal.textColor,
                              taglineColor: pal.taglineColor,
                              backgroundColor: pal.backgroundColor,
                            }))
                          }
                          className="w-full flex items-center justify-between p-2.5 rounded-xl border border-slate-200 hover:border-slate-300 transition text-left"
                        >
                          <span className="text-xs font-semibold text-slate-800">{pal.name}</span>
                          <div className="flex items-center gap-1.5">
                            <span className="w-4 h-4 rounded-full" style={{ backgroundColor: pal.primary }} />
                            <span className="w-4 h-4 rounded-full" style={{ backgroundColor: pal.secondary }} />
                            <span className="w-4 h-4 rounded-full" style={{ backgroundColor: pal.accent }} />
                            <span className="w-4 h-4 rounded-full border border-slate-300" style={{ backgroundColor: pal.backgroundColor }} />
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Custom Pickers */}
                  <div className="pt-2 border-t border-slate-100 space-y-3">
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider">
                      Fine-Tune Exact Hex Colors
                    </label>

                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <span className="text-[11px] font-medium text-slate-600 block mb-1">Primary Icon</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={logo.primaryColor}
                            onChange={(e) => updateLogo((prev) => ({ ...prev, primaryColor: e.target.value }))}
                            className="w-8 h-8 rounded-lg cursor-pointer border border-slate-200"
                          />
                          <span className="text-xs font-mono text-slate-700">{logo.primaryColor}</span>
                        </div>
                      </div>

                      <div>
                        <span className="text-[11px] font-medium text-slate-600 block mb-1">Brand Text</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={logo.textColor}
                            onChange={(e) => updateLogo((prev) => ({ ...prev, textColor: e.target.value }))}
                            className="w-8 h-8 rounded-lg cursor-pointer border border-slate-200"
                          />
                          <span className="text-xs font-mono text-slate-700">{logo.textColor}</span>
                        </div>
                      </div>

                      <div>
                        <span className="text-[11px] font-medium text-slate-600 block mb-1">Accent Accent</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={logo.accentColor}
                            onChange={(e) => updateLogo((prev) => ({ ...prev, accentColor: e.target.value }))}
                            className="w-8 h-8 rounded-lg cursor-pointer border border-slate-200"
                          />
                          <span className="text-xs font-mono text-slate-700">{logo.accentColor}</span>
                        </div>
                      </div>

                      <div>
                        <span className="text-[11px] font-medium text-slate-600 block mb-1">Background Canvas</span>
                        <div className="flex items-center gap-2">
                          <input
                            type="color"
                            value={logo.backgroundColor === 'transparent' ? '#ffffff' : logo.backgroundColor}
                            onChange={(e) =>
                              updateLogo((prev) => ({
                                ...prev,
                                backgroundColor: e.target.value,
                                hasTransparentBg: false,
                              }))
                            }
                            className="w-8 h-8 rounded-lg cursor-pointer border border-slate-200"
                          />
                          <span className="text-xs font-mono text-slate-700">{logo.backgroundColor}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: LAYOUT & ALIGNMENT */}
              {activeTab === 'layout' && (
                <div className="space-y-5">
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Logo Structure Layout
                    </label>
                    <div className="grid grid-cols-2 gap-2.5">
                      {(['horizontal', 'vertical', 'stacked', 'badge', 'icon-only'] as LogoLayout[]).map((mode) => (
                        <button
                          key={mode}
                          onClick={() => updateLogo((prev) => ({ ...prev, layout: mode }))}
                          className={`p-3 rounded-2xl border text-left transition ${
                            logo.layout === mode
                              ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 font-bold'
                              : 'border-slate-200 text-slate-700 hover:bg-slate-50'
                          }`}
                        >
                          <div className="text-xs capitalize font-semibold">{mode.replace('-', ' ')}</div>
                          <div className="text-[10px] text-slate-500 mt-0.5">
                            {mode === 'horizontal' && 'Standard header badge'}
                            {mode === 'vertical' && 'Centered emblem mark'}
                            {mode === 'stacked' && 'Compact vertical text'}
                            {mode === 'badge' && 'Framed crest shield'}
                            {mode === 'icon-only' && 'Favicon / app icon'}
                          </div>
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Alignment buttons */}
                  <div>
                    <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">
                      Text Alignment
                    </label>
                    <div className="grid grid-cols-3 gap-2">
                      <button
                        onClick={() => updateLogo((prev) => ({ ...prev, alignment: 'left' }))}
                        className={`flex items-center justify-center gap-1.5 py-2 rounded-xl border text-xs font-medium transition ${
                          logo.alignment === 'left'
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                            : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <AlignLeft className="w-3.5 h-3.5" />
                        Left
                      </button>

                      <button
                        onClick={() => updateLogo((prev) => ({ ...prev, alignment: 'center' }))}
                        className={`flex items-center justify-center gap-1.5 py-2 rounded-xl border text-xs font-medium transition ${
                          logo.alignment === 'center'
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                            : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <AlignCenter className="w-3.5 h-3.5" />
                        Center
                      </button>

                      <button
                        onClick={() => updateLogo((prev) => ({ ...prev, alignment: 'right' }))}
                        className={`flex items-center justify-center gap-1.5 py-2 rounded-xl border text-xs font-medium transition ${
                          logo.alignment === 'right'
                            ? 'border-indigo-600 bg-indigo-50 text-indigo-700'
                            : 'border-slate-200 text-slate-600 hover:bg-slate-50'
                        }`}
                      >
                        <AlignRight className="w-3.5 h-3.5" />
                        Right
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: MOCKUPS EMBEDDED */}
              {activeTab === 'mockups' && (
                <div>
                  <MockupPreview logo={logo} />
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Realistic Mockups Section below Editor */}
        {activeTab !== 'mockups' && (
          <div className="mt-12">
            <MockupPreview logo={logo} />
          </div>
        )}
      </div>
    </div>
  );
};
