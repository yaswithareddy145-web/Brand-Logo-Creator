import React, { useState } from 'react';
import {
  Industry,
  LogoConfig,
  LogoStyle,
  ColorPalette,
} from '../types/logo';
import {
  COLOR_PALETTES,
  generateFallbackLogos,
} from '../utils/logoTemplates';
import { LogoRenderer } from './LogoRenderer';
import { downloadPng, downloadSvg } from '../utils/exporter';
import { saveLogo } from '../utils/storage';
import {
  Sparkles,
  Sliders,
  Palette,
  Briefcase,
  Layers,
  ArrowRight,
  Loader2,
  Check,
  Bookmark,
  ExternalLink,
  Download,
  AlertCircle,
  Lightbulb,
  Cpu,
  RefreshCw,
  Wand2,
} from 'lucide-react';

interface LogoStudioProps {
  onSelectLogoForEdit: (logo: LogoConfig) => void;
  initialBrandName?: string;
}

const INDUSTRIES: Industry[] = [
  'Technology',
  'Education',
  'Fashion',
  'Food',
  'Healthcare',
  'Gaming',
  'Beauty',
  'Finance',
  'Travel',
  'Other',
];

const LOGO_STYLES: { id: LogoStyle; label: string; desc: string; icon: string }[] = [
  { id: 'Minimalist', label: 'Minimalist', desc: 'Clean, understated, essential shapes', icon: '◻' },
  { id: 'Modern', label: 'Modern', desc: 'Sleek tech gradients & bold sans-serifs', icon: '⚡' },
  { id: 'Luxury', label: 'Luxury', desc: 'Opulent serifs, gold foils & regal crests', icon: '✦' },
  { id: 'Vintage', label: 'Vintage', desc: 'Heritage stamps, badges & retro seals', icon: '✪' },
  { id: 'Abstract', label: 'Abstract', desc: 'Conceptual geometric art & dynamic flows', icon: '❖' },
  { id: 'Mascot', label: 'Mascot', desc: 'Friendly characters, emblems & motifs', icon: '◈' },
  { id: 'Geometric', label: 'Geometric', desc: 'Golden ratios, hexagons & sharp angles', icon: '▲' },
  { id: 'Lettermark', label: 'Lettermark', desc: 'Monograms & striking typographic initials', icon: '𝔐' },
];

export const LogoStudio: React.FC<LogoStudioProps> = ({
  onSelectLogoForEdit,
  initialBrandName = '',
}) => {
  // Form State
  const [brandName, setBrandName] = useState(initialBrandName || '');
  const [tagline, setTagline] = useState('');
  const [industry, setIndustry] = useState<Industry>('Technology');
  const [style, setStyle] = useState<LogoStyle>('Modern');
  const [selectedPalette, setSelectedPalette] = useState<ColorPalette>(COLOR_PALETTES[0]);
  const [useCustomColors, setUseCustomColors] = useState(false);
  const [customColors, setCustomColors] = useState({
    primary: '#7c3aed',
    secondary: '#3b82f6',
    accent: '#06b6d4',
  });
  const [symbolPreference, setSymbolPreference] = useState('');
  const [description, setDescription] = useState('');
  const [variationsCount, setVariationsCount] = useState<number>(4);

  // Generation status
  const [isGenerating, setIsGenerating] = useState(false);
  const [generationStep, setGenerationStep] = useState('');
  const [generatedLogos, setGeneratedLogos] = useState<LogoConfig[]>([]);
  const [engineSource, setEngineSource] = useState<'gemini_flash' | 'template_engine' | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [savedIds, setSavedIds] = useState<Set<string>>(new Set());

  // Quick suggestions helper
  const handleApplyPresetIdea = (preset: {
    brand: string;
    tagline: string;
    ind: Industry;
    sty: LogoStyle;
    symbol: string;
    desc: string;
  }) => {
    setBrandName(preset.brand);
    setTagline(preset.tagline);
    setIndustry(preset.ind);
    setStyle(preset.sty);
    setSymbolPreference(preset.symbol);
    setDescription(preset.desc);
  };

  const handleGenerate = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!brandName.trim()) {
      setErrorMessage('Please provide a brand or company name to continue.');
      return;
    }

    setErrorMessage(null);
    setIsGenerating(true);
    setGenerationStep('Connecting to AI Studio backend...');

    const stepTimer1 = setTimeout(() => {
      setGenerationStep('Synthesizing vector geometry with Gemini...');
    }, 1200);

    const stepTimer2 = setTimeout(() => {
      setGenerationStep('Pairing typography and color psychology...');
    }, 2500);

    try {
      const response = await fetch('/api/generate-logos', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          brandName,
          tagline,
          industry,
          style,
          symbolPreference,
          description,
          customColors: useCustomColors ? customColors : undefined,
          colorPalette: selectedPalette,
          variationsCount,
        }),
      });

      clearTimeout(stepTimer1);
      clearTimeout(stepTimer2);

      const data = await response.json();

      if (data.success && Array.isArray(data.logos) && data.logos.length > 0) {
        setGeneratedLogos(data.logos);
        setEngineSource(data.source === 'gemini_flash' ? 'gemini_flash' : 'template_engine');
      } else {
        // Fallback to high quality vector templates
        console.warn('API returned fallback:', data.message || data.errorMessage);
        const fallbacks = generateFallbackLogos(
          brandName,
          tagline,
          industry,
          style,
          selectedPalette,
          useCustomColors ? customColors : undefined,
          variationsCount
        );
        setGeneratedLogos(fallbacks);
        setEngineSource('template_engine');
        if (data.errorMessage) {
          setErrorMessage(data.errorMessage);
        }
      }
    } catch (err: any) {
      console.error('Generation fetch error:', err);
      // Graceful client fallback
      const fallbacks = generateFallbackLogos(
        brandName,
        tagline,
        industry,
        style,
        selectedPalette,
        useCustomColors ? customColors : undefined,
        variationsCount
      );
      setGeneratedLogos(fallbacks);
      setEngineSource('template_engine');
      setErrorMessage('Connected via vector design engine.');
    } finally {
      setIsGenerating(false);
      setGenerationStep('');
      // Scroll to results
      setTimeout(() => {
        document.getElementById('studio-results-section')?.scrollIntoView({ behavior: 'smooth' });
      }, 200);
    }
  };

  const handleSaveConcept = (logo: LogoConfig) => {
    saveLogo(logo);
    setSavedIds((prev) => new Set(prev).add(logo.id));
  };

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
      {/* Studio Header */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-gradient-to-r from-purple-500/10 via-indigo-500/10 to-blue-500/10 border border-indigo-200/60 text-indigo-700 text-xs font-semibold mb-4">
          <Sparkles className="w-3.5 h-3.5 text-indigo-600" />
          <span>AI Logo Creation Studio</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
          Design Your Brand Identity in Seconds
        </h1>
        <p className="mt-2.5 text-slate-600 text-sm sm:text-base leading-relaxed">
          Specify your vision, industry, and aesthetic. Our AI engine computes tailored vector
          geometry, typography, and professional color harmonies.
        </p>
      </div>

      {/* Main Studio Card & Form */}
      <div className="bg-white rounded-3xl border border-slate-200/90 shadow-xl overflow-hidden p-6 sm:p-10 mb-12">
        <form onSubmit={handleGenerate} className="space-y-8">
          {/* Section 1: Brand Fundamentals */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                1
              </span>
              <h2 className="text-base font-bold text-slate-900">Brand Identity Basics</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Brand or Company Name <span className="text-rose-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={brandName}
                  onChange={(e) => setBrandName(e.target.value)}
                  placeholder="e.g. Lumina Technologies, Velvet Bakery, Apex Finance"
                  className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-slate-900 font-semibold focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Optional Tagline or Slogan
                </label>
                <input
                  type="text"
                  value={tagline}
                  onChange={(e) => setTagline(e.target.value)}
                  placeholder="e.g. Next-Gen Autonomous Intelligence"
                  className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition"
                />
              </div>
            </div>

            {/* Quick Inspiration Chips */}
            <div className="flex flex-wrap items-center gap-2 pt-1 text-xs">
              <span className="text-slate-400 font-medium flex items-center gap-1">
                <Lightbulb className="w-3.5 h-3.5 text-amber-500" /> Try an example:
              </span>
              {[
                {
                  brand: 'NeuroSync',
                  tagline: 'Cognitive Cloud Architectures',
                  ind: 'Technology' as Industry,
                  sty: 'Modern' as LogoStyle,
                  symbol: 'Synapse or neural circuit node',
                  desc: 'High-tech AI infrastructure and cloud platform.',
                },
                {
                  brand: 'Aethelgard',
                  tagline: 'Old-World Botanical Distillers',
                  ind: 'Food' as Industry,
                  sty: 'Vintage' as LogoStyle,
                  symbol: 'Heritage crest with oak leaves',
                  desc: 'Artisanal organic craft beverages in glass bottles.',
                },
                {
                  brand: 'Solara Living',
                  tagline: 'Nordic Interior Atelier',
                  ind: 'Fashion' as Industry,
                  sty: 'Minimalist' as LogoStyle,
                  symbol: 'Geometric sun arc',
                  desc: 'Warm minimalist furniture and sustainable textiles.',
                },
              ].map((chip) => (
                <button
                  type="button"
                  key={chip.brand}
                  onClick={() => handleApplyPresetIdea(chip)}
                  className="px-3 py-1 rounded-full bg-slate-100 hover:bg-indigo-50 hover:text-indigo-600 text-slate-600 border border-slate-200 transition text-[11px] font-medium"
                >
                  {chip.brand} ({chip.ind})
                </button>
              ))}
            </div>
          </div>

          {/* Section 2: Industry & Style */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                2
              </span>
              <h2 className="text-base font-bold text-slate-900">Industry & Visual Style</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Industry Dropdown */}
              <div className="md:col-span-1">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Primary Industry
                </label>
                <div className="relative">
                  <select
                    value={industry}
                    onChange={(e) => setIndustry(e.target.value as Industry)}
                    className="w-full px-4 py-3 rounded-2xl border border-slate-200 bg-white text-slate-900 font-medium focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition appearance-none cursor-pointer"
                  >
                    {INDUSTRIES.map((ind) => (
                      <option key={ind} value={ind}>
                        {ind}
                      </option>
                    ))}
                  </select>
                  <div className="absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none text-slate-400">
                    ▼
                  </div>
                </div>
                <p className="text-[11px] text-slate-500 mt-1.5">
                  Shapes the metaphorical iconography and archetype.
                </p>
              </div>

              {/* Logo Styles Grid */}
              <div className="md:col-span-2">
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Logo Style / Aesthetic Archetype
                </label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                  {LOGO_STYLES.map((st) => (
                    <button
                      type="button"
                      key={st.id}
                      onClick={() => setStyle(st.id)}
                      className={`p-3 rounded-2xl border text-left transition flex flex-col justify-between ${
                        style === st.id
                          ? 'border-indigo-600 bg-indigo-50/70 text-indigo-900 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700 bg-white'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-sm font-bold">{st.icon}</span>
                        {style === st.id && <Check className="w-3.5 h-3.5 text-indigo-600" />}
                      </div>
                      <div className="text-xs font-bold">{st.label}</div>
                      <div className="text-[10px] text-slate-500 line-clamp-1 mt-0.5">{st.desc}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Section 3: Colors & Palettes */}
          <div className="space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2.5">
                <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                  3
                </span>
                <h2 className="text-base font-bold text-slate-900">Color Palette & Mood</h2>
              </div>
              <button
                type="button"
                onClick={() => setUseCustomColors(!useCustomColors)}
                className="text-xs font-semibold text-indigo-600 hover:text-indigo-800"
              >
                {useCustomColors ? 'Use Preset Harmonies' : 'Custom Color Pickers'}
              </button>
            </div>

            {!useCustomColors ? (
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {COLOR_PALETTES.map((pal) => (
                  <button
                    type="button"
                    key={pal.id}
                    onClick={() => setSelectedPalette(pal)}
                    className={`p-3 rounded-2xl border text-left transition ${
                      selectedPalette.id === pal.id
                        ? 'border-indigo-600 bg-indigo-50/40 ring-2 ring-indigo-500/20'
                        : 'border-slate-200 hover:border-slate-300 bg-white'
                    }`}
                  >
                    <div className="flex items-center gap-1.5 mb-2">
                      <span className="w-5 h-5 rounded-full shadow-xs" style={{ backgroundColor: pal.primary }} />
                      <span className="w-5 h-5 rounded-full shadow-xs" style={{ backgroundColor: pal.secondary }} />
                      <span className="w-5 h-5 rounded-full shadow-xs" style={{ backgroundColor: pal.accent }} />
                    </div>
                    <div className="text-xs font-bold text-slate-800 truncate">{pal.name}</div>
                  </button>
                ))}
              </div>
            ) : (
              <div className="bg-slate-50 p-4 rounded-2xl border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Primary Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={customColors.primary}
                      onChange={(e) => setCustomColors((c) => ({ ...c, primary: e.target.value }))}
                      className="w-10 h-10 rounded-xl cursor-pointer border border-slate-300 shadow-xs"
                    />
                    <span className="text-xs font-mono font-semibold text-slate-800">
                      {customColors.primary}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Secondary Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={customColors.secondary}
                      onChange={(e) => setCustomColors((c) => ({ ...c, secondary: e.target.value }))}
                      className="w-10 h-10 rounded-xl cursor-pointer border border-slate-300 shadow-xs"
                    />
                    <span className="text-xs font-mono font-semibold text-slate-800">
                      {customColors.secondary}
                    </span>
                  </div>
                </div>

                <div>
                  <label className="text-xs font-bold text-slate-700 block mb-1">Accent Color</label>
                  <div className="flex items-center gap-3">
                    <input
                      type="color"
                      value={customColors.accent}
                      onChange={(e) => setCustomColors((c) => ({ ...c, accent: e.target.value }))}
                      className="w-10 h-10 rounded-xl cursor-pointer border border-slate-300 shadow-xs"
                    />
                    <span className="text-xs font-mono font-semibold text-slate-800">
                      {customColors.accent}
                    </span>
                  </div>
                </div>
              </div>
            )}
          </div>

          {/* Section 4: Details, Variations & Creative Prompt */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5 pb-2 border-b border-slate-100">
              <span className="w-6 h-6 rounded-full bg-indigo-600 text-white flex items-center justify-center text-xs font-bold">
                4
              </span>
              <h2 className="text-base font-bold text-slate-900">Creative Direction & Variations</h2>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Preferred Icon / Symbol (Optional)
                </label>
                <input
                  type="text"
                  value={symbolPreference}
                  onChange={(e) => setSymbolPreference(e.target.value)}
                  placeholder="e.g. geometric prism, eagle crest, lotus leaf, interconnected cube"
                  className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Variations to Generate
                </label>
                <div className="grid grid-cols-3 gap-3">
                  {[2, 4, 6].map((num) => (
                    <button
                      type="button"
                      key={num}
                      onClick={() => setVariationsCount(num)}
                      className={`py-3 rounded-2xl border text-center font-bold text-sm transition ${
                        variationsCount === num
                          ? 'border-indigo-600 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-500/20'
                          : 'border-slate-200 hover:border-slate-300 text-slate-700'
                      }`}
                    >
                      {num} Concepts
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                Creative Vision & Brand Story (Optional)
              </label>
              <textarea
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your target audience, core values, or any specific visual metaphor you'd love to see..."
                className="w-full px-4 py-3 rounded-2xl border border-slate-200 text-slate-900 focus:outline-none focus:ring-2 focus:ring-indigo-500/30 focus:border-indigo-500 transition"
              />
            </div>
          </div>

          {/* Error feedback if any */}
          {errorMessage && (
            <div className="p-4 rounded-2xl bg-amber-50 border border-amber-200 flex items-center gap-3 text-xs text-amber-800">
              <AlertCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <span>{errorMessage}</span>
            </div>
          )}

          {/* Prominent Action Button */}
          <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-2 text-xs text-slate-500">
              <Cpu className="w-4 h-4 text-indigo-500" />
              <span>Powered by Gemini 3.8 Flash vector design pipeline</span>
            </div>

            <button
              type="submit"
              disabled={isGenerating || !brandName.trim()}
              className="w-full sm:w-auto px-8 py-4 rounded-2xl font-bold text-white bg-gradient-to-r from-indigo-600 via-purple-600 to-blue-600 hover:from-indigo-700 hover:via-purple-700 hover:to-blue-700 shadow-lg shadow-indigo-500/25 transition active:scale-95 disabled:opacity-50 disabled:pointer-events-none flex items-center justify-center gap-2.5 text-base"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>{generationStep || 'Generating Logos...'}</span>
                </>
              ) : (
                <>
                  <Wand2 className="w-5 h-5" />
                  <span>Generate Logos with AI</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Results Section */}
      <div id="studio-results-section" className="space-y-6">
        {generatedLogos.length > 0 && (
          <div className="bg-white rounded-3xl border border-slate-200/90 shadow-sm p-6 sm:p-8">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-6 border-b border-slate-100">
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="text-xl font-extrabold text-slate-900 tracking-tight">
                    Generated Concepts for {brandName}
                  </h3>
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {generatedLogos.length} Variations
                  </span>
                </div>
                <p className="text-xs text-slate-500 mt-1">
                  {engineSource === 'gemini_flash'
                    ? '✨ Custom generated via Gemini 3.8 Flash structured vector engine.'
                    : '🎨 Rendered using precision vector design engine.'}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={() => handleGenerate()}
                  disabled={isGenerating}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-xs font-semibold text-slate-700 hover:bg-slate-50 transition flex items-center gap-1.5"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isGenerating ? 'animate-spin' : ''}`} />
                  Regenerate
                </button>
              </div>
            </div>

            {/* Generated Cards Gallery */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
              {generatedLogos.map((concept, index) => {
                const isCurrentlySaved = savedIds.has(concept.id);

                return (
                  <div
                    key={concept.id}
                    className="group bg-slate-50/50 hover:bg-white rounded-3xl border border-slate-200/90 hover:border-indigo-300 shadow-xs hover:shadow-xl transition-all duration-300 flex flex-col justify-between overflow-hidden"
                  >
                    {/* Concept Card Header */}
                    <div className="p-4 px-6 flex items-center justify-between border-b border-slate-100/80 bg-white">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-indigo-600 tracking-wider">
                          Concept #{index + 1}
                        </span>
                        <h4 className="text-sm font-bold text-slate-900">{concept.conceptName}</h4>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleSaveConcept(concept)}
                          className={`p-2 rounded-xl text-xs font-medium transition ${
                            isCurrentlySaved
                              ? 'bg-emerald-50 text-emerald-600'
                              : 'text-slate-500 hover:bg-slate-100'
                          }`}
                          title="Save to My Designs"
                        >
                          {isCurrentlySaved ? <Check className="w-4 h-4" /> : <Bookmark className="w-4 h-4" />}
                        </button>

                        <button
                          onClick={() => onSelectLogoForEdit(concept)}
                          className="px-3 py-1.5 rounded-xl bg-indigo-50 text-indigo-600 hover:bg-indigo-600 hover:text-white text-xs font-bold transition flex items-center gap-1"
                        >
                          <span>Edit</span>
                          <ExternalLink className="w-3 h-3" />
                        </button>
                      </div>
                    </div>

                    {/* Logo Render Canvas */}
                    <div
                      onClick={() => onSelectLogoForEdit(concept)}
                      className="cursor-pointer relative p-8 flex items-center justify-center min-h-[240px] bg-white transition group-hover:scale-[1.01]"
                    >
                      <LogoRenderer config={concept} scale={0.88} />
                    </div>

                    {/* Rationale and Quick Action Footer */}
                    <div className="p-4 px-6 bg-slate-50/90 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                      <p className="text-slate-600 text-[11px] line-clamp-2 sm:max-w-[65%]">
                        {concept.rationale}
                      </p>

                      <div className="flex items-center gap-2 self-end sm:self-auto">
                        <button
                          onClick={() => downloadSvg(concept, false)}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 text-[11px] font-semibold flex items-center gap-1"
                          title="Quick export vector SVG"
                        >
                          <Download className="w-3 h-3" />
                          SVG
                        </button>
                        <button
                          onClick={() => downloadPng(concept, true)}
                          className="px-2.5 py-1.5 rounded-lg border border-slate-200 bg-white text-slate-700 hover:bg-slate-100 text-[11px] font-semibold flex items-center gap-1"
                          title="Quick export transparent PNG"
                        >
                          <Download className="w-3 h-3" />
                          PNG
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
