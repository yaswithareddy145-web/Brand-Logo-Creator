import { LogoConfig } from '../types/logo';
import { renderLogoToSvgString } from './logoTemplates';
import confetti from 'canvas-confetti';

export function downloadSvg(config: LogoConfig, transparent: boolean = false): void {
  const svgString = renderLogoToSvgString(config, transparent);
  const blob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  
  const link = document.createElement('a');
  link.href = url;
  const sanitizedName = config.brandName.toLowerCase().replace(/[^a-z0-9]/g, '_');
  link.download = `${sanitizedName}_logo_${transparent ? 'transparent' : 'full'}.svg`;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);

  triggerConfetti();
}

export async function downloadPng(
  config: LogoConfig,
  transparent: boolean = false,
  scale: number = 2
): Promise<void> {
  const width = 800 * scale;
  const height = 600 * scale;

  const svgString = renderLogoToSvgString(config, transparent);
  const svgBlob = new Blob([svgString], { type: 'image/svg+xml;charset=utf-8' });
  const url = URL.createObjectURL(svgBlob);

  const img = new Image();
  img.crossOrigin = 'anonymous';

  return new Promise((resolve, reject) => {
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) {
        reject(new Error('Failed to create canvas context'));
        return;
      }

      if (!transparent && !config.hasTransparentBg) {
        ctx.fillStyle = config.backgroundColor || '#ffffff';
        ctx.fillRect(0, 0, width, height);
      } else {
        ctx.clearRect(0, 0, width, height);
      }

      ctx.drawImage(img, 0, 0, width, height);
      URL.revokeObjectURL(url);

      canvas.toBlob((blob) => {
        if (!blob) {
          reject(new Error('Canvas to Blob conversion failed'));
          return;
        }
        const downloadUrl = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = downloadUrl;
        const sanitizedName = config.brandName.toLowerCase().replace(/[^a-z0-9]/g, '_');
        link.download = `${sanitizedName}_logo_${transparent ? 'transparent' : 'hq'}.png`;
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        URL.revokeObjectURL(downloadUrl);

        triggerConfetti();
        resolve();
      }, 'image/png');
    };

    img.onerror = (err) => {
      URL.revokeObjectURL(url);
      reject(err);
    };

    img.src = url;
  });
}

export function copySvgCode(config: LogoConfig, transparent: boolean = false): Promise<void> {
  const svgString = renderLogoToSvgString(config, transparent);
  return navigator.clipboard.writeText(svgString);
}

function triggerConfetti() {
  try {
    confetti({
      particleCount: 70,
      spread: 60,
      origin: { y: 0.8 },
      colors: ['#7c3aed', '#3b82f6', '#06b6d4', '#10b981'],
    });
  } catch (e) {
    // Ignore confetti issues if any
  }
}
