import { LogoConfig } from '../types/logo';
import { SAMPLE_LOGOS } from './logoTemplates';

const STORAGE_KEY = 'logocraft_saved_designs_v1';

export function getSavedLogos(): LogoConfig[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      // Seed with 2 sample designs initially so the user has immediate examples
      const initial = [SAMPLE_LOGOS[0], SAMPLE_LOGOS[2]];
      localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
      return initial;
    }
    return JSON.parse(raw);
  } catch (err) {
    console.error('Failed to read from localStorage:', err);
    return [];
  }
}

export function saveLogo(logo: LogoConfig): void {
  try {
    const existing = getSavedLogos();
    const index = existing.findIndex((l) => l.id === logo.id);
    const updatedLogo = { ...logo, updatedAt: new Date().toISOString() };
    
    let updatedList: LogoConfig[];
    if (index >= 0) {
      updatedList = [...existing];
      updatedList[index] = updatedLogo;
    } else {
      updatedList = [updatedLogo, ...existing];
    }
    
    localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedList));
  } catch (err) {
    console.error('Failed to save logo to localStorage:', err);
  }
}

export function deleteLogo(id: string): void {
  try {
    const existing = getSavedLogos();
    const filtered = existing.filter((l) => l.id !== id);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(filtered));
  } catch (err) {
    console.error('Failed to delete logo from localStorage:', err);
  }
}

export function getLogoById(id: string): LogoConfig | null {
  const all = getSavedLogos();
  return all.find((l) => l.id === id) || null;
}
