import { ColorPalette, Industry, LogoConfig, LogoStyle } from '../types/logo';

export const COLOR_PALETTES: ColorPalette[] = [
  {
    id: 'cyber-violet',
    name: 'Electric Purple & Indigo',
    primary: '#7c3aed',
    secondary: '#3b82f6',
    accent: '#06b6d4',
    textColor: '#0f172a',
    taglineColor: '#64748b',
    backgroundColor: '#ffffff',
  },
  {
    id: 'midnight-neon',
    name: 'Midnight Dark & Cyan',
    primary: '#06b6d4',
    secondary: '#8b5cf6',
    accent: '#f43f5e',
    textColor: '#ffffff',
    taglineColor: '#94a3b8',
    backgroundColor: '#0f172a',
  },
  {
    id: 'emerald-luxury',
    name: 'Royal Emerald & Mint',
    primary: '#059669',
    secondary: '#10b981',
    accent: '#f59e0b',
    textColor: '#064e3b',
    taglineColor: '#047857',
    backgroundColor: '#ffffff',
  },
  {
    id: 'luxury-gold',
    name: 'Imperial Gold & Onyx',
    primary: '#d97706',
    secondary: '#b45309',
    accent: '#fbbf24',
    textColor: '#18181b',
    taglineColor: '#71717a',
    backgroundColor: '#ffffff',
  },
  {
    id: 'sunset-blaze',
    name: 'Sunset Orange & Rose',
    primary: '#f97316',
    secondary: '#e11d48',
    accent: '#8b5cf6',
    textColor: '#1c1917',
    taglineColor: '#78716c',
    backgroundColor: '#ffffff',
  },
  {
    id: 'oceanic-blue',
    name: 'Deep Pacific & Aqua',
    primary: '#2563eb',
    secondary: '#0284c7',
    accent: '#38bdf8',
    textColor: '#0f172a',
    taglineColor: '#64748b',
    backgroundColor: '#ffffff',
  },
  {
    id: 'mono-minimal',
    name: 'Monochrome Minimal',
    primary: '#0f172a',
    secondary: '#475569',
    accent: '#94a3b8',
    textColor: '#0f172a',
    taglineColor: '#64748b',
    backgroundColor: '#ffffff',
  },
  {
    id: 'rose-petal',
    name: 'Soft Rose & Burgundy',
    primary: '#e11d48',
    secondary: '#be185d',
    accent: '#f43f5e',
    textColor: '#881337',
    taglineColor: '#9f1239',
    backgroundColor: '#ffffff',
  },
];

export const FONT_OPTIONS = [
  { name: 'Space Grotesk', value: "'Space Grotesk', sans-serif", category: 'Modern Tech' },
  { name: 'Outfit', value: "'Outfit', sans-serif", category: 'Clean Geometric' },
  { name: 'Plus Jakarta Sans', value: "'Plus Jakarta Sans', sans-serif", category: 'SaaS Modern' },
  { name: 'Cinzel', value: "'Cinzel', serif", category: 'Luxury Classic' },
  { name: 'Playfair Display', value: "'Playfair Display', serif", category: 'Elegant Editorial' },
  { name: 'Montserrat', value: "'Montserrat', sans-serif", category: 'Bold Corporate' },
  { name: 'Syne', value: "'Syne', sans-serif", category: 'Avant-garde Arts' },
  { name: 'Unbounded', value: "'Unbounded', sans-serif", category: 'Futuristic Gaming' },
  { name: 'Inter', value: "'Inter', sans-serif", category: 'Ultra Clean' },
];

// Rich vector shapes & icons organized by style & industry
export const ICON_LIBRARY: { id: string; name: string; category: string; paths: string }[] = [
  {
    id: 'nexus-cube',
    name: 'Isometric Cube',
    category: 'Technology',
    paths: `
      <polygon points="50,15 85,35 50,55 15,35" fill="currentColor" fill-opacity="0.9" />
      <polygon points="15,35 50,55 50,90 15,70" fill="currentColor" fill-opacity="0.65" />
      <polygon points="50,55 85,35 85,70 50,90" fill="currentColor" fill-opacity="0.4" />
      <circle cx="50" cy="55" r="5" fill="#ffffff" />
    `,
  },
  {
    id: 'dynamic-spark',
    name: 'Prism Spark',
    category: 'Technology',
    paths: `
      <path d="M50 5 L63 37 L95 50 L63 63 L50 95 L37 63 L5 50 L37 37 Z" fill="currentColor" />
      <circle cx="50" cy="50" r="14" fill="#ffffff" />
      <circle cx="50" cy="50" r="7" fill="currentColor" />
    `,
  },
  {
    id: 'infinity-loop',
    name: 'Infinite Helix',
    category: 'Technology',
    paths: `
      <path d="M30 35 C 15 35, 10 65, 30 65 C 45 65, 55 35, 70 35 C 90 35, 85 65, 70 65 C 55 65, 45 35, 30 35 Z" 
            fill="none" stroke="currentColor" stroke-width="12" stroke-linecap="round" stroke-linejoin="round" />
      <circle cx="30" cy="50" r="4" fill="currentColor" />
      <circle cx="70" cy="50" r="4" fill="currentColor" />
    `,
  },
  {
    id: 'modern-crown',
    name: 'Imperial Crown',
    category: 'Luxury',
    paths: `
      <path d="M20 75 L80 75 L85 40 L65 55 L50 25 L35 55 L15 40 Z" fill="currentColor" />
      <circle cx="50" cy="20" r="4" fill="currentColor" />
      <circle cx="15" cy="35" r="3.5" fill="currentColor" />
      <circle cx="85" cy="35" r="3.5" fill="currentColor" />
      <rect x="22" y="80" width="56" height="5" rx="2.5" fill="currentColor" />
    `,
  },
  {
    id: 'geometric-diamond',
    name: 'Faceted Diamond',
    category: 'Luxury',
    paths: `
      <polygon points="30,25 70,25 88,48 50,85 12,48" fill="currentColor" fill-opacity="0.2" stroke="currentColor" stroke-width="6" stroke-linejoin="round"/>
      <polygon points="30,25 50,48 70,25" fill="currentColor" fill-opacity="0.8" />
      <polygon points="12,48 50,48 30,25" fill="currentColor" fill-opacity="0.5" />
      <polygon points="88,48 50,48 70,25" fill="currentColor" fill-opacity="0.5" />
      <polygon points="12,48 50,85 50,48" fill="currentColor" fill-opacity="0.7" />
      <polygon points="88,48 50,85 50,48" fill="currentColor" fill-opacity="0.9" />
    `,
  },
  {
    id: 'leaf-zenith',
    name: 'Eco Zenith Leaf',
    category: 'Healthcare',
    paths: `
      <path d="M50 15 C 75 15, 85 45, 80 75 C 65 75, 40 65, 30 50 C 20 35, 30 15, 50 15 Z" fill="currentColor" />
      <path d="M50 15 C 45 45, 60 65, 80 75" fill="none" stroke="#ffffff" stroke-width="4" stroke-linecap="round" />
      <path d="M25 65 C 20 80, 45 85, 55 85 C 45 80, 30 75, 25 65 Z" fill="currentColor" fill-opacity="0.6" />
    `,
  },
  {
    id: 'cyber-shield',
    name: 'Aegis Shield',
    category: 'Finance',
    paths: `
      <path d="M50 15 L80 28 V52 C80 70 50 88 50 88 C50 88 20 70 20 52 V28 Z" fill="currentColor" fill-opacity="0.15" stroke="currentColor" stroke-width="7" stroke-linejoin="round" />
      <path d="M42 50 L48 56 L62 40" fill="none" stroke="currentColor" stroke-width="8" stroke-linecap="round" stroke-linejoin="round" />
    `,
  },
  {
    id: 'pulse-wave',
    name: 'Growth Pulse',
    category: 'Finance',
    paths: `
      <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" stroke-width="6" />
      <path d="M22 55 L35 55 L43 32 L53 68 L62 45 L70 55 L78 55" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round" stroke-linejoin="round" />
    `,
  },
  {
    id: 'creative-flame',
    name: 'Genesis Flame',
    category: 'Food',
    paths: `
      <path d="M50 12 C50 12 72 35 72 58 C72 72 62 88 50 88 C38 88 28 72 28 58 C28 42 42 30 42 30 C42 30 38 46 45 52 C50 56 56 50 50 12 Z" fill="currentColor" />
      <circle cx="50" cy="68" r="9" fill="#ffffff" fill-opacity="0.8" />
    `,
  },
  {
    id: 'modern-monogram-hexagon',
    name: 'Hexagon Matrix',
    category: 'Minimalist',
    paths: `
      <polygon points="50,10 88,32 88,76 50,98 12,76 12,32" fill="none" stroke="currentColor" stroke-width="8" stroke-linejoin="round" />
      <circle cx="50" cy="54" r="16" fill="currentColor" />
      <line x1="50" y1="20" x2="50" y2="38" stroke="currentColor" stroke-width="6" stroke-linecap="round" />
      <line x1="75" y1="67" x2="62" y2="60" stroke="currentColor" stroke-width="6" stroke-linecap="round" />
      <line x1="25" y1="67" x2="38" y2="60" stroke="currentColor" stroke-width="6" stroke-linecap="round" />
    `,
  },
  {
    id: 'feather-quill',
    name: 'Scholar Quill',
    category: 'Education',
    paths: `
      <path d="M78 15 C45 22 28 55 24 85 L32 85 C34 70 42 55 58 45 L50 55 L65 52 L60 62 L75 58 C80 45 84 28 78 15 Z" fill="currentColor" />
      <circle cx="22" cy="85" r="3" fill="currentColor" />
    `,
  },
  {
    id: 'game-blade',
    name: 'Valkyrie Blade',
    category: 'Gaming',
    paths: `
      <polygon points="50,10 65,40 50,88 35,40" fill="currentColor" />
      <polygon points="50,30 80,48 68,58 50,45" fill="currentColor" fill-opacity="0.6" />
      <polygon points="50,30 20,48 32,58 50,45" fill="currentColor" fill-opacity="0.6" />
      <circle cx="50" cy="94" r="4" fill="currentColor" />
    `,
  },
  {
    id: 'compass-rose',
    name: 'Wanderer Compass',
    category: 'Travel',
    paths: `
      <circle cx="50" cy="50" r="40" fill="none" stroke="currentColor" stroke-width="5" />
      <polygon points="50,15 57,43 50,50 43,43" fill="currentColor" />
      <polygon points="85,50 57,57 50,50 57,43" fill="currentColor" fill-opacity="0.6" />
      <polygon points="50,85 43,57 50,50 57,57" fill="currentColor" fill-opacity="0.4" />
      <polygon points="15,50 43,43 50,50 43,57" fill="currentColor" fill-opacity="0.7" />
      <circle cx="50" cy="50" r="5" fill="#ffffff" />
    `,
  },
  {
    id: 'lotus-harmony',
    name: 'Zen Lotus',
    category: 'Beauty',
    paths: `
      <path d="M50 20 C60 40 70 55 80 65 C68 68 55 60 50 45 C45 60 32 68 20 65 C30 55 40 40 50 20 Z" fill="currentColor" />
      <path d="M50 35 C58 50 65 65 65 75 C55 77 45 72 40 62 C35 72 25 77 15 75 C15 65 22 50 30 35 C38 48 45 52 50 35 Z" fill="currentColor" fill-opacity="0.6" />
      <ellipse cx="50" cy="80" rx="20" ry="4" fill="currentColor" fill-opacity="0.4" />
    `,
  },
  {
    id: 'vintage-seal',
    name: 'Heritage Crest',
    category: 'Vintage',
    paths: `
      <circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" stroke-width="4" stroke-dasharray="4 3" />
      <circle cx="50" cy="50" r="34" fill="none" stroke="currentColor" stroke-width="2" />
      <path d="M50 24 L56 38 L72 38 L60 48 L64 64 L50 54 L36 64 L40 48 L28 38 L44 38 Z" fill="currentColor" />
      <circle cx="50" cy="50" r="7" fill="#ffffff" />
    `,
  },
  {
    id: 'origami-bird',
    name: 'Origami Crane',
    category: 'Abstract',
    paths: `
      <polygon points="20,40 50,15 60,35" fill="currentColor" fill-opacity="0.8" />
      <polygon points="50,15 85,30 60,35" fill="currentColor" fill-opacity="0.6" />
      <polygon points="60,35 85,30 65,70" fill="currentColor" fill-opacity="0.9" />
      <polygon points="20,40 60,35 45,75" fill="currentColor" />
      <polygon points="45,75 65,70 50,90" fill="currentColor" fill-opacity="0.7" />
    `,
  },
];

// Curated sample logos for the homepage showcase and initial inspiration
export const SAMPLE_LOGOS: LogoConfig[] = [
  {
    id: 'sample-1',
    brandName: 'NEXUS',
    tagline: 'AUTONOMOUS CLOUD INTELLIGENCE',
    industry: 'Technology',
    style: 'Modern',
    conceptName: 'Nexus Matrix',
    rationale: 'Clean geometric isometric cube signifying modular computing and scalable cloud architecture.',
    layout: 'horizontal',
    alignment: 'left',
    fontFamily: "'Space Grotesk', sans-serif",
    fontWeight: '700',
    letterSpacing: 2,
    textSize: 38,
    textTransform: 'uppercase',
    taglineFont: "'Inter', sans-serif",
    taglineSize: 11,
    taglineLetterSpacing: 3,
    taglineTransform: 'uppercase',
    iconSvg: ICON_LIBRARY[0].paths,
    iconSize: 52,
    iconRotation: 0,
    iconShapeBackground: 'none',
    primaryColor: '#7c3aed',
    secondaryColor: '#3b82f6',
    accentColor: '#06b6d4',
    textColor: '#0f172a',
    taglineColor: '#64748b',
    backgroundColor: '#ffffff',
    showTagline: true,
    showIcon: true,
    hasTransparentBg: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sample-2',
    brandName: 'AURA',
    tagline: 'HAUTE PARFUMERIE PARIS',
    industry: 'Fashion',
    style: 'Luxury',
    conceptName: 'Gilded Crest',
    rationale: 'Imperial faceted crown with regal symmetry for fine fragrances and couture houses.',
    layout: 'vertical',
    alignment: 'center',
    fontFamily: "'Cinzel', serif",
    fontWeight: '700',
    letterSpacing: 6,
    textSize: 40,
    textTransform: 'uppercase',
    taglineFont: "'Montserrat', sans-serif",
    taglineSize: 10,
    taglineLetterSpacing: 4,
    taglineTransform: 'uppercase',
    iconSvg: ICON_LIBRARY[3].paths,
    iconSize: 58,
    iconRotation: 0,
    iconShapeBackground: 'circle',
    primaryColor: '#b45309',
    secondaryColor: '#d97706',
    accentColor: '#fde68a',
    textColor: '#1c1917',
    taglineColor: '#78716c',
    backgroundColor: '#ffffff',
    showTagline: true,
    showIcon: true,
    hasTransparentBg: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sample-3',
    brandName: 'PULSE',
    tagline: 'VENTURE CAPITAL & ASSET LAB',
    industry: 'Finance',
    style: 'Minimalist',
    conceptName: 'Capital Aegis',
    rationale: 'Secured geometric shield emblem with dynamic check vector embodying financial trust.',
    layout: 'horizontal',
    alignment: 'left',
    fontFamily: "'Outfit', sans-serif",
    fontWeight: '800',
    letterSpacing: 1,
    textSize: 36,
    textTransform: 'uppercase',
    taglineFont: "'Plus Jakarta Sans', sans-serif",
    taglineSize: 10,
    taglineLetterSpacing: 2,
    taglineTransform: 'uppercase',
    iconSvg: ICON_LIBRARY[6].paths,
    iconSize: 48,
    iconRotation: 0,
    iconShapeBackground: 'rounded',
    primaryColor: '#2563eb',
    secondaryColor: '#0284c7',
    accentColor: '#38bdf8',
    textColor: '#0f172a',
    taglineColor: '#475569',
    backgroundColor: '#ffffff',
    showTagline: true,
    showIcon: true,
    hasTransparentBg: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sample-4',
    brandName: 'VERDANT',
    tagline: 'ORGANIC BOTANICAL BOTTLING',
    industry: 'Healthcare',
    style: 'Geometric',
    conceptName: 'Zenith Leaf',
    rationale: 'Minimalist biomorphic leaf with interior radial sunburst evoking wellness and vitality.',
    layout: 'vertical',
    alignment: 'center',
    fontFamily: "'Playfair Display', serif",
    fontWeight: '700',
    letterSpacing: 2,
    textSize: 36,
    textTransform: 'uppercase',
    taglineFont: "'Inter', sans-serif",
    taglineSize: 9,
    taglineLetterSpacing: 3,
    taglineTransform: 'uppercase',
    iconSvg: ICON_LIBRARY[5].paths,
    iconSize: 52,
    iconRotation: 0,
    iconShapeBackground: 'none',
    primaryColor: '#059669',
    secondaryColor: '#10b981',
    accentColor: '#34d399',
    textColor: '#064e3b',
    taglineColor: '#047857',
    backgroundColor: '#ffffff',
    showTagline: true,
    showIcon: true,
    hasTransparentBg: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sample-5',
    brandName: 'CYPHR',
    tagline: 'NEXT-GEN ESPORTS & ARENA',
    industry: 'Gaming',
    style: 'Modern',
    conceptName: 'Cyber Valkyrie',
    rationale: 'Sharp faceted razor blade and chevron geometry engineered for gaming guilds.',
    layout: 'horizontal',
    alignment: 'left',
    fontFamily: "'Unbounded', sans-serif",
    fontWeight: '800',
    letterSpacing: 1,
    textSize: 34,
    textTransform: 'uppercase',
    taglineFont: "'Space Grotesk', sans-serif",
    taglineSize: 10,
    taglineLetterSpacing: 2,
    taglineTransform: 'uppercase',
    iconSvg: ICON_LIBRARY[11].paths,
    iconSize: 50,
    iconRotation: 0,
    iconShapeBackground: 'none',
    primaryColor: '#8b5cf6',
    secondaryColor: '#ec4899',
    accentColor: '#06b6d4',
    textColor: '#ffffff',
    taglineColor: '#cbd5e1',
    backgroundColor: '#0f172a',
    showTagline: true,
    showIcon: true,
    hasTransparentBg: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
  {
    id: 'sample-6',
    brandName: 'SOLACE',
    tagline: 'HOLISTIC WELLBEING SANCTUARY',
    industry: 'Beauty',
    style: 'Minimalist',
    conceptName: 'Sacred Lotus',
    rationale: 'Calming multi-layered petal arcs with grounding symmetry for spa and beauty brands.',
    layout: 'vertical',
    alignment: 'center',
    fontFamily: "'Syne', sans-serif",
    fontWeight: '700',
    letterSpacing: 4,
    textSize: 34,
    textTransform: 'uppercase',
    taglineFont: "'Outfit', sans-serif",
    taglineSize: 9,
    taglineLetterSpacing: 3,
    taglineTransform: 'uppercase',
    iconSvg: ICON_LIBRARY[13].paths,
    iconSize: 48,
    iconRotation: 0,
    iconShapeBackground: 'circle',
    primaryColor: '#e11d48',
    secondaryColor: '#f43f5e',
    accentColor: '#fda4af',
    textColor: '#881337',
    taglineColor: '#9f1239',
    backgroundColor: '#ffffff',
    showTagline: true,
    showIcon: true,
    hasTransparentBg: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  },
];

// Helper to generate a fallback logo variation based on form inputs
export function generateFallbackLogos(
  brandName: string,
  tagline: string = '',
  industry: Industry,
  style: LogoStyle,
  colorPalette?: ColorPalette,
  customColors?: { primary: string; secondary: string; accent: string },
  count: number = 4
): LogoConfig[] {
  const chosenPalette = colorPalette || COLOR_PALETTES[0];
  const primary = customColors?.primary || chosenPalette.primary;
  const secondary = customColors?.secondary || chosenPalette.secondary;
  const accent = customColors?.accent || chosenPalette.accent;

  // Filter or match icons for industry
  const matchingIcons = ICON_LIBRARY.filter(
    (i) => i.category.toLowerCase() === industry.toLowerCase() || i.category.toLowerCase() === style.toLowerCase()
  );
  const pool = matchingIcons.length > 0 ? matchingIcons : ICON_LIBRARY;

  const fontCandidates = FONT_OPTIONS;
  const layouts: ('horizontal' | 'vertical' | 'stacked' | 'badge')[] = ['horizontal', 'vertical', 'stacked', 'badge'];

  const results: LogoConfig[] = [];

  for (let idx = 0; idx < count; idx++) {
    const iconItem = pool[idx % pool.length];
    const layout = layouts[idx % layouts.length];
    const font = fontCandidates[(idx * 2) % fontCandidates.length];

    // Vary shapes and color tones
    const bg = idx === 1 && style === 'Modern' ? '#0f172a' : '#ffffff';
    const textCol = bg === '#0f172a' ? '#ffffff' : '#0f172a';
    const tagCol = bg === '#0f172a' ? '#94a3b8' : '#64748b';

    results.push({
      id: `generated-${Date.now()}-${idx}`,
      brandName: brandName.trim() || 'BrandName',
      tagline: tagline.trim() || 'DEFINING EXCELLENCE',
      industry,
      style,
      conceptName: `${style} ${iconItem.name}`,
      rationale: `Bespoke ${style.toLowerCase()} concept utilizing a ${iconItem.name.toLowerCase()} icon with ${font.name} typography tailored for ${industry}.`,
      layout,
      alignment: layout === 'horizontal' ? 'left' : 'center',
      fontFamily: font.value,
      fontWeight: '700',
      letterSpacing: layout === 'vertical' ? 3 : 1.5,
      textSize: layout === 'vertical' ? 36 : 34,
      textTransform: 'uppercase',
      taglineFont: "'Inter', sans-serif",
      taglineSize: 10,
      taglineLetterSpacing: 2.5,
      taglineTransform: 'uppercase',
      iconSvg: iconItem.paths,
      iconSize: layout === 'vertical' ? 56 : 48,
      iconRotation: 0,
      iconShapeBackground: idx % 2 === 0 ? 'none' : 'rounded',
      primaryColor: primary,
      secondaryColor: secondary,
      accentColor: accent,
      textColor: textCol,
      taglineColor: tagCol,
      backgroundColor: bg,
      showTagline: Boolean(tagline.trim()),
      showIcon: true,
      hasTransparentBg: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    });
  }

  return results;
}

// Convert LogoConfig into standalone pure SVG markup for export or canvas drawing
export function renderLogoToSvgString(config: LogoConfig, transparent: boolean = false): string {
  const width = 800;
  const height = 600;
  const bg = transparent || config.hasTransparentBg ? 'none' : config.backgroundColor;

  // Coordinates calculation based on layout
  const isHorizontal = config.layout === 'horizontal';
  const isVertical = config.layout === 'vertical';
  const isBadge = config.layout === 'badge';
  const isIconOnly = config.layout === 'icon-only';

  const iconScale = (config.iconSize || 48) / 100;
  const iconW = 100 * iconScale * 2.4;
  const iconH = 100 * iconScale * 2.4;

  let contentMarkup = '';

  if (isIconOnly) {
    const iconX = (width - iconW) / 2;
    const iconY = (height - iconH) / 2;
    contentMarkup = `
      <g transform="translate(${iconX}, ${iconY}) scale(${iconScale * 2.4})" color="${config.primaryColor}">
        ${config.iconSvg}
      </g>
    `;
  } else if (isHorizontal) {
    // Icon on left, text on right
    const gap = 36;
    const totalContentWidth = config.showIcon ? iconW + gap + 380 : 400;
    const startX = (width - totalContentWidth) / 2;
    const centerY = height / 2;

    const iconX = startX;
    const iconY = centerY - iconH / 2;
    const textX = config.showIcon ? startX + iconW + gap : width / 2;
    const textAnchor = config.showIcon ? 'start' : 'middle';

    contentMarkup = `
      ${
        config.showIcon
          ? `<g transform="translate(${iconX}, ${iconY}) scale(${iconScale * 2.4})" color="${config.primaryColor}">
              ${config.iconSvg}
            </g>`
          : ''
      }
      <g text-anchor="${textAnchor}">
        <text 
          x="${textX}" 
          y="${config.showTagline && config.tagline ? centerY - 6 : centerY + config.textSize / 3}" 
          font-family="${config.fontFamily.replace(/"/g, "'")}" 
          font-weight="${config.fontWeight}" 
          font-size="${config.textSize * 1.3}px" 
          letter-spacing="${config.letterSpacing}px" 
          fill="${config.textColor}">
          ${escapeXml(config.brandName)}
        </text>
        ${
          config.showTagline && config.tagline
            ? `<text 
                x="${textX}" 
                y="${centerY + config.taglineSize * 1.4 + 10}" 
                font-family="${config.taglineFont.replace(/"/g, "'")}" 
                font-size="${config.taglineSize * 1.3}px" 
                letter-spacing="${config.taglineLetterSpacing}px" 
                fill="${config.taglineColor}"
                font-weight="500">
                ${escapeXml(config.tagline)}
              </text>`
            : ''
        }
      </g>
    `;
  } else if (isVertical) {
    // Icon on top, text in middle, tagline below
    const centerY = height / 2;
    const iconX = (width - iconW) / 2;
    const iconY = config.showIcon ? centerY - iconH - 24 : centerY - 30;

    contentMarkup = `
      ${
        config.showIcon
          ? `<g transform="translate(${iconX}, ${iconY}) scale(${iconScale * 2.4})" color="${config.primaryColor}">
              ${config.iconSvg}
            </g>`
          : ''
      }
      <g text-anchor="middle">
        <text 
          x="${width / 2}" 
          y="${config.showIcon ? centerY + 50 : centerY}" 
          font-family="${config.fontFamily.replace(/"/g, "'")}" 
          font-weight="${config.fontWeight}" 
          font-size="${config.textSize * 1.3}px" 
          letter-spacing="${config.letterSpacing}px" 
          fill="${config.textColor}">
          ${escapeXml(config.brandName)}
        </text>
        ${
          config.showTagline && config.tagline
            ? `<text 
                x="${width / 2}" 
                y="${config.showIcon ? centerY + 86 : centerY + 36}" 
                font-family="${config.taglineFont.replace(/"/g, "'")}" 
                font-size="${config.taglineSize * 1.3}px" 
                letter-spacing="${config.taglineLetterSpacing}px" 
                fill="${config.taglineColor}"
                font-weight="500">
                ${escapeXml(config.tagline)}
              </text>`
            : ''
        }
      </g>
    `;
  } else {
    // Badge / Shield / Emblem container
    const centerY = height / 2;
    contentMarkup = `
      <rect x="${width / 2 - 190}" y="${centerY - 160}" width="380" height="320" rx="32" fill="${config.primaryColor}" fill-opacity="0.08" stroke="${config.primaryColor}" stroke-width="4"/>
      <g transform="translate(${width / 2 - iconW / 2}, ${centerY - 110}) scale(${iconScale * 2.2})" color="${config.primaryColor}">
        ${config.iconSvg}
      </g>
      <g text-anchor="middle">
        <text 
          x="${width / 2}" 
          y="${centerY + 50}" 
          font-family="${config.fontFamily.replace(/"/g, "'")}" 
          font-weight="${config.fontWeight}" 
          font-size="${config.textSize * 1.2}px" 
          letter-spacing="${config.letterSpacing}px" 
          fill="${config.textColor}">
          ${escapeXml(config.brandName)}
        </text>
        ${
          config.showTagline && config.tagline
            ? `<text 
                x="${width / 2}" 
                y="${centerY + 86}" 
                font-family="${config.taglineFont.replace(/"/g, "'")}" 
                font-size="${config.taglineSize * 1.2}px" 
                letter-spacing="${config.taglineLetterSpacing}px" 
                fill="${config.taglineColor}"
                font-weight="500">
                ${escapeXml(config.tagline)}
              </text>`
            : ''
        }
      </g>
    `;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${width} ${height}" width="${width}" height="${height}">
  <defs>
    <style>
      @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;800&amp;family=Inter:wght@400;500;600;700&amp;family=Montserrat:wght@600;700;800&amp;family=Outfit:wght@600;700;800&amp;family=Playfair+Display:ital,wght@0,600;0,800&amp;family=Plus+Jakarta+Sans:wght@600;700;800&amp;family=Space+Grotesk:wght@600;700&amp;family=Syne:wght@700;800&amp;family=Unbounded:wght@700;800&amp;display=swap');
    </style>
  </defs>
  ${bg !== 'none' ? `<rect width="100%" height="100%" fill="${bg}" />` : ''}
  ${contentMarkup}
</svg>`;
}

function escapeXml(unsafe: string): string {
  return unsafe.replace(/[<>&'"]/g, (c) => {
    switch (c) {
      case '<':
        return '&lt;';
      case '>':
        return '&gt;';
      case '&':
        return '&amp;';
      case '\'':
        return '&apos;';
      case '"':
        return '&quot;';
      default:
        return c;
    }
  });
}
