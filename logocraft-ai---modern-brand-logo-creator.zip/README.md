# 🎨 AI Logo & Brand Creator

A lightweight, open-source AI logo generator that instantly designs minimal, vector-ready logos and text branding assets.

🚀 **[Live Demo on Netlify]()**

## ✨ Features

- **Text-to-Logo generation:** Generate sleek logos from simple brand prompts.
- **Customization presets:** Toggle between minimal, corporate, and abstract styles.
- **Multi-format export:** Download assets seamlessly in SVG, PNG, or favicon sizes.

## 🛠️ Quick Start

```bash
# Clone the repository
git clone https://github.com

# Install dependencies
npm install

# Run the local development server
npm run dev
```

## 🌐 Deployment

🚀 **[Live Demo on Netlify]()**
[Netlify](https://brand-logo-creator.netlify.app/)\*\*.
