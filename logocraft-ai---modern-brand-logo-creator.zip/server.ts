import express, { Request, Response } from 'express';
import { createServer as createViteServer } from 'vite';
import dotenv from 'dotenv';
import path from 'path';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const app = express();
const PORT = 3000;
const isProd = process.env.NODE_ENV === 'production';

app.use(express.json({ limit: '10mb' }));

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
let aiClient: GoogleGenAI | null = null;

if (apiKey) {
  aiClient = new GoogleGenAI({
    apiKey: apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasApiKey: Boolean(apiKey),
    timestamp: new Date().toISOString(),
  });
});

// Primary logo generation endpoint using Gemini 3.8 Flash
app.post('/api/generate-logos', async (req: Request, res: Response) => {
  try {
    const {
      brandName = 'Acme',
      tagline = '',
      industry = 'Technology',
      style = 'Modern',
      symbolPreference = '',
      description = '',
      customColors,
      variationsCount = 4,
    } = req.body;

    const count = Math.min(Math.max(Number(variationsCount) || 4, 1), 6);

    if (!aiClient || !apiKey) {
      return res.json({
        success: true,
        source: 'template_engine',
        message: 'No GEMINI_API_KEY detected in environment; generated using vector design engine.',
        logos: [],
      });
    }

    const systemInstruction = `You are a world-class brand identity designer and vector logo specialist.
Your task is to generate ${count} distinct, creative, professional logo concepts for a brand.
Each logo concept must include:
1. conceptName: A brief punchy name for the design concept.
2. rationale: 1-2 sentences explaining the design psychology and symbolism.
3. layout: One of 'horizontal', 'vertical', 'stacked', 'badge'.
4. fontFamily: One of 'Space Grotesk', 'Outfit', 'Cinzel', 'Playfair Display', 'Montserrat', 'Syne', 'Unbounded', 'Inter'.
5. fontWeight: '700' or '800'.
6. primaryColor: A modern hex color suited for the industry and user preferences.
7. secondaryColor: A harmonious secondary hex color.
8. accentColor: An accent hex color.
9. textColor: Hex color for the brand text (e.g. #0f172a, #1e293b, #ffffff).
10. backgroundColor: Hex color (#ffffff, #f8fafc, #0f172a, etc.).
11. iconSvgPaths: Crisp, valid SVG inner elements (only <path>, <polygon>, <circle>, <rect>, etc.) inside a 0 0 100 100 viewBox coordinate system. Use "currentColor" or SVG fill/stroke so it renders cleanly and dynamically. Avoid markdown formatting inside the string.`;

    const userPrompt = `Brand Name: "${brandName}"
Tagline: "${tagline || 'None'}"
Industry: "${industry}"
Style: "${style}"
Symbol/Icon Preference: "${symbolPreference || 'Creative geometric or industry metaphor'}"
User Description & Vision: "${description || 'Clean, memorable, high-end vector logo'}"
${customColors ? `Requested Colors: Primary=${customColors.primary}, Secondary=${customColors.secondary}, Accent=${customColors.accent}` : ''}
Generate ${count} distinct, memorable logo concepts with valid inner SVG elements.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: userPrompt,
      config: {
        systemInstruction,
        temperature: 0.8,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            concepts: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  conceptName: { type: Type.STRING },
                  rationale: { type: Type.STRING },
                  layout: { type: Type.STRING, enum: ['horizontal', 'vertical', 'stacked', 'badge'] },
                  fontFamily: { type: Type.STRING },
                  fontWeight: { type: Type.STRING },
                  primaryColor: { type: Type.STRING },
                  secondaryColor: { type: Type.STRING },
                  accentColor: { type: Type.STRING },
                  textColor: { type: Type.STRING },
                  backgroundColor: { type: Type.STRING },
                  iconSvgPaths: { type: Type.STRING },
                },
                required: [
                  'conceptName',
                  'rationale',
                  'layout',
                  'fontFamily',
                  'primaryColor',
                  'secondaryColor',
                  'accentColor',
                  'textColor',
                  'backgroundColor',
                  'iconSvgPaths',
                ],
              },
            },
          },
          required: ['concepts'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    const concepts = parsed.concepts || [];

    if (!Array.isArray(concepts) || concepts.length === 0) {
      throw new Error('AI returned an empty concepts list');
    }

    const formattedLogos = concepts.map((item: any, idx: number) => ({
      id: `ai-${Date.now()}-${idx}`,
      brandName: brandName.trim(),
      tagline: tagline.trim(),
      industry,
      style,
      conceptName: item.conceptName || `${style} Mark ${idx + 1}`,
      rationale: item.rationale || 'Engineered by Gemini AI based on brand industry and typography requirements.',
      layout: item.layout || (idx % 2 === 0 ? 'horizontal' : 'vertical'),
      alignment: item.layout === 'horizontal' ? 'left' : 'center',
      fontFamily: `'${item.fontFamily || 'Outfit'}', sans-serif`,
      fontWeight: item.fontWeight || '700',
      letterSpacing: item.layout === 'vertical' ? 3 : 1.5,
      textSize: item.layout === 'vertical' ? 36 : 34,
      textTransform: 'uppercase',
      taglineFont: "'Inter', sans-serif",
      taglineSize: 10,
      taglineLetterSpacing: 2.5,
      taglineTransform: 'uppercase',
      iconSvg: item.iconSvgPaths || '<circle cx="50" cy="50" r="35" fill="currentColor"/>',
      iconSize: item.layout === 'vertical' ? 56 : 48,
      iconRotation: 0,
      iconShapeBackground: 'none',
      primaryColor: item.primaryColor || '#7c3aed',
      secondaryColor: item.secondaryColor || '#3b82f6',
      accentColor: item.accentColor || '#06b6d4',
      textColor: item.textColor || '#0f172a',
      taglineColor: item.textColor === '#ffffff' ? '#94a3b8' : '#64748b',
      backgroundColor: item.backgroundColor || '#ffffff',
      showTagline: Boolean(tagline.trim()),
      showIcon: true,
      hasTransparentBg: false,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }));

    res.json({
      success: true,
      source: 'gemini_flash',
      logos: formattedLogos,
    });
  } catch (error: any) {
    console.error('Error generating logos via Gemini:', error);
    // Graceful fallback response
    res.json({
      success: true,
      source: 'fallback_due_to_error',
      errorMessage: error.message || 'Gemini generation encountered an issue; falling back to vector engine.',
      logos: [],
    });
  }
});

// Endpoint to generate raster image artwork via Gemini Image Generation (if available)
app.post('/api/generate-ai-image', async (req: Request, res: Response) => {
  try {
    const { prompt, brandName, style, industry } = req.body;

    if (!aiClient || !apiKey) {
      return res.status(400).json({
        success: false,
        error: 'Gemini API Key is not configured on the server.',
      });
    }

    const imagePrompt = `Professional vector brand logo icon for "${brandName}". Industry: ${industry}. Style: ${style} aesthetic. Details: ${prompt || 'clean geometric icon symbol'}. Minimalist, vector art, centered on pure solid white background, high contrast, graphic design, no mockups, no realistic photo artifacts.`;

    const response = await aiClient.models.generateContent({
      model: 'gemini-3.1-flash-lite-image',
      contents: {
        parts: [
          {
            text: imagePrompt,
          },
        ],
      },
    });

    let base64Image: string | null = null;
    if (response.candidates && response.candidates[0]?.content?.parts) {
      for (const part of response.candidates[0].content.parts) {
        if (part.inlineData && part.inlineData.data) {
          base64Image = `data:${part.inlineData.mimeType || 'image/png'};base64,${part.inlineData.data}`;
          break;
        }
      }
    }

    if (!base64Image) {
      return res.status(500).json({
        success: false,
        error: 'No image data returned from Gemini image model.',
      });
    }

    res.json({
      success: true,
      imageUrl: base64Image,
    });
  } catch (err: any) {
    console.warn('Image generation unavailable or requires paid key:', err.message);
    res.status(402).json({
      success: false,
      error: err.message || 'Image generation model requires paid credentials or was unavailable.',
      requiresPaidKey: true,
    });
  }
});

// Setup Vite or static serving
async function startServer() {
  if (!isProd) {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`LogoCraft AI server running on port ${PORT}`);
  });
}

startServer();
